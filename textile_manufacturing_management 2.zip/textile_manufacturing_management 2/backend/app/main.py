import os
from datetime import datetime, timezone
from typing import Any, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, ConfigDict
from pymongo import MongoClient, DESCENDING
from pymongo.errors import PyMongoError
from bson import ObjectId

MONGODB_URL = os.getenv("MONGODB_URL", "mongodb://localhost:27017")
DATABASE_NAME = os.getenv("DATABASE_NAME", "textileflow")
origins = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")

client = MongoClient(MONGODB_URL, serverSelectionTimeoutMS=5000)
db = client[DATABASE_NAME]

app = FastAPI(
    title="TextileFlow API",
    description="REST API for textile vendors, materials, production, staff, warehouses, and distribution.",
    version="1.0.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in origins] + ["http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

COLLECTIONS = {
    "vendors": "vendors",
    "materials": "materials",
    "production": "production_batches",
    "employees": "employees",
    "warehouses": "warehouses",
    "distributors": "distributors",
    "retailers": "retailers",
}

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def clean(doc: dict) -> dict:
    doc = dict(doc)
    doc["id"] = str(doc.pop("_id"))
    if isinstance(doc.get("created_at"), datetime):
        doc["created_at"] = doc["created_at"].isoformat()
    return doc

def get_collection(key: str):
    if key not in COLLECTIONS:
        raise HTTPException(status_code=404, detail="Unknown resource")
    return db[COLLECTIONS[key]]

def seed_if_empty():
    if db.vendors.count_documents({}) > 0:
        return
    vendors = [
        {"name":"Deccan Cotton Traders","city":"Pune","contact":"Aarav Kulkarni","phone":"+91 98765 10001","materials_supplied":"Cotton yarn","status":"Active"},
        {"name":"Western Dyes & Chemicals","city":"Surat","contact":"Meera Shah","phone":"+91 98765 10002","materials_supplied":"Textile dyes","status":"Active"},
        {"name":"LoomLine Fibres","city":"Coimbatore","contact":"Karthik Rao","phone":"+91 98765 10003","materials_supplied":"Polyester fibre","status":"Active"},
    ]
    db.vendors.insert_many([dict(x, created_at=now_iso()) for x in vendors])
    db.materials.insert_many([
        {"name":"Cotton yarn","sku":"RM-COT-001","category":"Yarn","quantity":1250,"unit":"kg","reorder_level":300,"vendor":"Deccan Cotton Traders","created_at":now_iso()},
        {"name":"Reactive blue dye","sku":"RM-DYE-014","category":"Dye","quantity":85,"unit":"kg","reorder_level":100,"vendor":"Western Dyes & Chemicals","created_at":now_iso()},
        {"name":"Polyester fibre","sku":"RM-POL-006","category":"Fibre","quantity":920,"unit":"kg","reorder_level":250,"vendor":"LoomLine Fibres","created_at":now_iso()},
    ])
    db.production_batches.insert_many([
        {"batch_code":"BATCH-26041","fabric_type":"Cotton Poplin","unit_name":"Pune Weaving Unit","quantity_meters":4200,"status":"In Progress","supervisor":"R. Patil","shift":"Morning","created_at":now_iso()},
        {"batch_code":"BATCH-26042","fabric_type":"Poly-Cotton Twill","unit_name":"Surat Processing Unit","quantity_meters":6800,"status":"Completed","supervisor":"S. Desai","shift":"Evening","created_at":now_iso()},
        {"batch_code":"BATCH-26043","fabric_type":"Denim","unit_name":"Pune Weaving Unit","quantity_meters":2500,"status":"Queued","supervisor":"A. Jadhav","shift":"Night","created_at":now_iso()},
    ])
    db.employees.insert_many([
        {"name":"Rohan Patil","employee_code":"EMP-0101","role":"Production Supervisor","unit":"Pune Weaving Unit","shift":"Morning","created_at":now_iso()},
        {"name":"Sneha Desai","employee_code":"EMP-0102","role":"Quality Analyst","unit":"Surat Processing Unit","shift":"Evening","created_at":now_iso()},
        {"name":"Amit Jadhav","employee_code":"EMP-0103","role":"Machine Operator","unit":"Pune Weaving Unit","shift":"Night","created_at":now_iso()},
    ])
    db.warehouses.insert_many([
        {"name":"Central Finished Goods","city":"Pune","capacity_meters":50000,"stock_meters":18400,"manager":"N. Joshi","created_at":now_iso()},
        {"name":"West Distribution Hub","city":"Surat","capacity_meters":35000,"stock_meters":22100,"manager":"P. Mehta","created_at":now_iso()},
    ])
    db.distributors.insert_many([
        {"name":"Maharashtra Textile Supply","city":"Mumbai","contact":"Kunal Shah","phone":"+91 98765 20001","region":"West","created_at":now_iso()},
        {"name":"South Loom Distributors","city":"Bengaluru","contact":"Divya Nair","phone":"+91 98765 20002","region":"South","created_at":now_iso()},
    ])
    db.retailers.insert_many([
        {"name":"Thread & Weave Store","city":"Nashik","distributor":"Maharashtra Textile Supply","contact":"Pooja More","created_at":now_iso()},
        {"name":"Urban Fabric House","city":"Hyderabad","distributor":"South Loom Distributors","contact":"Rahul Reddy","created_at":now_iso()},
    ])

@app.on_event("startup")
def startup():
    try:
        client.admin.command("ping")
        seed_if_empty()
    except Exception as exc:
        print(f"MongoDB not ready at startup: {exc}")

class Record(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: Optional[str] = None
    created_at: Optional[str] = None

class VendorIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    city: str
    contact: str
    phone: str
    materials_supplied: str
    status: str = "Active"

class MaterialIn(BaseModel):
    name: str
    sku: str
    category: str
    quantity: float = Field(ge=0)
    unit: str = "kg"
    reorder_level: float = Field(ge=0)
    vendor: str

class ProductionIn(BaseModel):
    batch_code: str
    fabric_type: str
    unit_name: str
    quantity_meters: float = Field(gt=0)
    status: str = "Queued"
    supervisor: str
    shift: str

class EmployeeIn(BaseModel):
    name: str
    employee_code: str
    role: str
    unit: str
    shift: str

class WarehouseIn(BaseModel):
    name: str
    city: str
    capacity_meters: float = Field(gt=0)
    stock_meters: float = Field(ge=0)
    manager: str

class DistributorIn(BaseModel):
    name: str
    city: str
    contact: str
    phone: str
    region: str

class RetailerIn(BaseModel):
    name: str
    city: str
    distributor: str
    contact: str

MODELS = {
    "vendors": VendorIn,
    "materials": MaterialIn,
    "production": ProductionIn,
    "employees": EmployeeIn,
    "warehouses": WarehouseIn,
    "distributors": DistributorIn,
    "retailers": RetailerIn,
}

@app.get("/api/health")
def health():
    try:
        client.admin.command("ping")
        return {"status":"ok","database":"connected","database_name":DATABASE_NAME}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Database unavailable: {exc}")

@app.get("/api/dashboard")
def dashboard():
    material_count = db.materials.count_documents({})
    low_stock = list(db.materials.find({"$expr":{"$lte":["$quantity","$reorder_level"]}}, {"_id":0,"name":1,"quantity":1,"unit":1,"reorder_level":1}))
    batches = list(db.production_batches.find({}, {"_id":0,"batch_code":1,"fabric_type":1,"quantity_meters":1,"status":1,"unit_name":1,"created_at":1}).sort("_id", DESCENDING).limit(6))
    total_capacity = sum(float(x.get("capacity_meters",0)) for x in db.warehouses.find({}, {"capacity_meters":1}))
    total_stock = sum(float(x.get("stock_meters",0)) for x in db.warehouses.find({}, {"stock_meters":1}))
    production_total = sum(float(x.get("quantity_meters",0)) for x in db.production_batches.find({}, {"quantity_meters":1}))
    return {
        "kpis": {
            "vendors": db.vendors.count_documents({}),
            "materials": material_count,
            "production_batches": db.production_batches.count_documents({}),
            "employees": db.employees.count_documents({}),
            "warehouse_stock_meters": total_stock,
            "distributors": db.distributors.count_documents({}),
            "retailers": db.retailers.count_documents({}),
            "production_meters": production_total,
        },
        "low_stock": low_stock,
        "recent_batches": batches,
        "warehouse_utilization": round((total_stock / total_capacity * 100), 1) if total_capacity else 0,
    }

@app.get("/api/{resource}")
def list_records(resource: str, q: Optional[str] = Query(default=None), limit: int = Query(default=200, ge=1, le=500)):
    col = get_collection(resource)
    query = {}
    if q:
        query = {"$or":[{field:{"$regex":q,"$options":"i"}} for field in ["name","city","sku","batch_code","fabric_type","unit_name","employee_code","vendor","distributor","status","category","role"]]}
    docs = col.find(query).sort("_id", DESCENDING).limit(limit)
    return [clean(d) for d in docs]

@app.post("/api/{resource}", status_code=201)
def create_record(resource: str, payload: dict[str, Any]):
    if resource not in MODELS:
        raise HTTPException(status_code=404, detail="Unknown resource")
    try:
        validated = MODELS[resource](**payload).model_dump(exclude_none=True)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    validated["created_at"] = now_iso()
    try:
        result = get_collection(resource).insert_one(validated)
        return clean(get_collection(resource).find_one({"_id": result.inserted_id}))
    except PyMongoError as exc:
        raise HTTPException(status_code=500, detail=f"Database write failed: {exc}")

@app.delete("/api/{resource}/{record_id}")
def delete_record(resource: str, record_id: str):
    if resource not in COLLECTIONS:
        raise HTTPException(status_code=404, detail="Unknown resource")
    try:
        result = get_collection(resource).delete_one({"_id": ObjectId(record_id)})
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid record ID")
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Record not found")
    return {"deleted":True,"id":record_id}

@app.get("/")
def root():
    return {"name":"TextileFlow API","docs":"/docs","health":"/api/health"}
