import React, { useCallback, useEffect, useMemo, useState } from 'react'
import {
  Activity, ArrowDownRight, ArrowUpRight, Boxes, Building2, ChartNoAxesCombined,
  CheckCircle2, ChevronDown, CircleHelp, Factory, FilePlus2, LayoutDashboard,
  LoaderCircle, Menu, Package, Plus, RefreshCw, Search, ShieldCheck, Truck,
  Users, Warehouse, X, Trash2, AlertTriangle, Database, Wifi, WifiOff
} from 'lucide-react'
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
  BarChart, Bar
} from 'recharts'

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const sections = [
  { id:'dashboard', label:'Overview', icon:LayoutDashboard },
  { id:'vendors', label:'Vendors & Materials', icon:Boxes },
  { id:'production', label:'Production', icon:Factory },
  { id:'employees', label:'Employees & Shifts', icon:Users },
  { id:'warehouses', label:'Warehouses', icon:Warehouse },
  { id:'network', label:'Distribution Network', icon:Truck },
]
const resources = {
  vendors: { endpoint:'vendors', title:'Vendors', singular:'vendor', icon:Building2, fields:[
    ['name','Vendor name','text'],['city','City','text'],['contact','Contact person','text'],['phone','Phone','tel'],['materials_supplied','Materials supplied','text'],['status','Status','select',['Active','On Hold']]
  ]},
  materials: { endpoint:'materials', title:'Raw materials', singular:'material', icon:Package, fields:[
    ['name','Material name','text'],['sku','SKU / code','text'],['category','Category','select',['Yarn','Fibre','Dye','Chemical','Other']],['quantity','Quantity','number'],['unit','Unit','select',['kg','litres','rolls','units']],['reorder_level','Reorder level','number'],['vendor','Vendor','text']
  ]},
  production: { endpoint:'production', title:'Production batches', singular:'production batch', icon:Factory, fields:[
    ['batch_code','Batch code','text'],['fabric_type','Fabric type','text'],['unit_name','Production unit','select',['Pune Weaving Unit','Surat Processing Unit','Coimbatore Finishing Unit']],['quantity_meters','Quantity (meters)','number'],['status','Status','select',['Queued','In Progress','Completed','On Hold']],['supervisor','Supervisor','text'],['shift','Shift','select',['Morning','Evening','Night']]
  ]},
  employees: { endpoint:'employees', title:'Employees', singular:'employee', icon:Users, fields:[
    ['name','Full name','text'],['employee_code','Employee code','text'],['role','Role','select',['Production Supervisor','Quality Analyst','Machine Operator','Warehouse Staff','Logistics']],['unit','Unit','text'],['shift','Shift','select',['Morning','Evening','Night']]
  ]},
  warehouses: { endpoint:'warehouses', title:'Warehouses', singular:'warehouse', icon:Warehouse, fields:[
    ['name','Warehouse name','text'],['city','City','text'],['capacity_meters','Capacity (meters)','number'],['stock_meters','Current stock (meters)','number'],['manager','Warehouse manager','text']
  ]},
  distributors: { endpoint:'distributors', title:'Distributors', singular:'distributor', icon:Truck, fields:[
    ['name','Distributor name','text'],['city','City','text'],['contact','Contact person','text'],['phone','Phone','tel'],['region','Region','select',['North','South','East','West','Central']]
  ]},
  retailers: { endpoint:'retailers', title:'Retailers', singular:'retailer', icon:Building2, fields:[
    ['name','Retailer name','text'],['city','City','text'],['distributor','Distributor','text'],['contact','Contact person','text']
  ]},
}
const fmt = n => Number(n || 0).toLocaleString('en-IN')
const pretty = s => s.replaceAll('_',' ').replace(/\b\w/g, x => x.toUpperCase())
const toTitle = s => s.charAt(0).toUpperCase() + s.slice(1)

function App() {
  const [page, setPage] = useState('dashboard')
  const [dashboard, setDashboard] = useState(null)
  const [data, setData] = useState({})
  const [health, setHealth] = useState('checking')
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [modal, setModal] = useState(null)
  const [toast, setToast] = useState('')
  const [mobileNav, setMobileNav] = useState(false)

  const notify = msg => { setToast(msg); window.setTimeout(() => setToast(''), 3500) }
  const request = useCallback(async (path, options={}) => {
    const response = await fetch(`${API}${path}`, {
      headers: { 'Content-Type':'application/json', ...(options.headers || {}) }, ...options
    })
    if (!response.ok) {
      let detail = `Request failed (${response.status})`
      try { const body = await response.json(); detail = body.detail || detail } catch {}
      throw new Error(typeof detail === 'string' ? detail : JSON.stringify(detail))
    }
    return response.json()
  }, [])

  const refresh = useCallback(async () => {
    setLoading(true)
    try {
      const [dash, ...lists] = await Promise.all([
        request('/api/dashboard'),
        ...Object.entries(resources).map(([key, r]) => request(`/api/${r.endpoint}`))
      ])
      setDashboard(dash)
      setData(Object.fromEntries(Object.keys(resources).map((key, i) => [key, lists[i]])))
      setHealth('connected')
    } catch (e) {
      setHealth('offline')
      notify(`API connection issue: ${e.message}. Check that Docker/backend is running.`)
    } finally { setLoading(false) }
  }, [request])
  useEffect(() => { refresh() }, [refresh])

  const submitRecord = async (resource, payload) => {
    try {
      await request(`/api/${resources[resource].endpoint}`, { method:'POST', body:JSON.stringify(payload) })
      setModal(null)
      await refresh()
      notify(`${toTitle(resources[resource].singular)} saved to MongoDB`)
    } catch (e) { notify(`Could not save: ${e.message}`) }
  }
  const deleteRecord = async (resource, id) => {
    if (!window.confirm('Delete this record permanently?')) return
    try {
      await request(`/api/${resources[resource].endpoint}/${id}`, { method:'DELETE' })
      await refresh()
      notify('Record deleted from MongoDB')
    } catch (e) { notify(`Delete failed: ${e.message}`) }
  }

  const activeSection = sections.find(s => s.id === page) || sections[0]
  const allRecords = page === 'vendors' ? ['vendors','materials'] : page === 'network' ? ['distributors','retailers'] : page === 'dashboard' ? [] : [page]
  const isResourcePage = allRecords.length > 0
  const filtered = useMemo(() => Object.fromEntries(allRecords.map(k => [k, (data[k] || []).filter(row => !search || Object.values(row).some(v => String(v).toLowerCase().includes(search.toLowerCase())))])), [allRecords.join(','), data, search])
  const pageTitle = page === 'dashboard' ? 'Operations overview' : activeSection.label

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? 'mobile-open' : ''}`}>
      <div className="brand"><div className="brand-mark"><Factory size={22}/></div><div><strong>TextileFlow</strong><span>MANUFACTURING OS</span></div><button className="mobile-close" onClick={()=>setMobileNav(false)}><X size={18}/></button></div>
      <div className="workspace"><div className="workspace-avatar">TF</div><div><strong>Textile Group Ltd.</strong><span>Operations workspace</span></div><ChevronDown size={15}/></div>
      <div className="nav-label">WORKSPACE</div>
      <nav>{sections.map(item => <button key={item.id} className={`nav-item ${page===item.id?'active':''}`} onClick={()=>{setPage(item.id);setSearch('');setMobileNav(false)}}><item.icon size={18}/><span>{item.label}</span>{item.id==='vendors' && <span className="nav-count">{(data.materials||[]).length}</span>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="connection-card"><div className="connection-icon"><Database size={17}/></div><div><strong>Database status</strong><span className={health==='connected'?'status-live':'status-down'}><i/> {health==='connected'?'MongoDB connected':health==='checking'?'Checking connection':'API disconnected'}</span></div></div><div className="sidebar-foot"><ShieldCheck size={15}/> Textile operations console <span>v1.0</span></div></div>
    </aside>
    {mobileNav && <div className="nav-overlay" onClick={()=>setMobileNav(false)}/>}
    <main className="main-area">
      <header className="topbar"><div className="topbar-left"><button className="menu-btn" onClick={()=>setMobileNav(true)}><Menu size={20}/></button><div className="breadcrumb">Workspace <span>/</span> <strong>{pageTitle}</strong></div></div><div className="topbar-actions"><div className={`api-pill ${health}`}><span className="pulse-dot"/>{health==='connected'?'API connected':health==='checking'?'Connecting':'API offline'}</div><button className="icon-btn" title="Refresh data" onClick={refresh}><RefreshCw size={17}/></button><div className="user-avatar">OP</div></div></header>
      <div className="content">
        <div className="page-heading"><div><div className="eyebrow">TEXTILE GROUP / OPERATIONS</div><h1>{pageTitle}</h1><p>{page==='dashboard'?'A live snapshot of production, inventory and distribution.':page==='vendors'?'Manage supplier relationships and raw material stock.':page==='production'?'Track production batches across units and shifts.':page==='employees'?'Manage plant teams, job roles and shift assignments.':page==='warehouses'?'Monitor finished-goods stock and storage capacity.':'Manage distributors and retail outlets across cities.'}</p></div><div className="heading-actions"><span className="updated"><span className="pulse-dot"/> Live data</span><button className="btn btn-primary" onClick={()=>setModal({resource:page==='vendors'?'vendors':page==='production'?'production':page==='employees'?'employees':page==='warehouses'?'warehouses':page==='network'?'distributors':'vendors'})}><Plus size={17}/> Add record</button></div></div>
        {page==='dashboard' ? <Dashboard dashboard={dashboard} data={data} loading={loading} onNavigate={setPage} onAdd={r=>setModal({resource:r})}/> :
          <section className="data-section">
            <div className="section-toolbar"><div className="section-label"><span className="tiny-indicator"/>{allRecords.reduce((sum,k)=>sum+(data[k]||[]).length,0)} records in database</div><div className="toolbar-right"><div className="searchbox"><Search size={16}/><input placeholder="Search records..." value={search} onChange={e=>setSearch(e.target.value)}/>{search&&<button onClick={()=>setSearch('')}><X size={14}/></button>}</div>{allRecords.length>1&&<button className="btn btn-outline" onClick={()=>setModal({resource:allRecords[1]})}><Plus size={15}/> Add {resources[allRecords[1]].singular}</button>}</div></div>
            {allRecords.map(resource => <DataTable key={resource} resource={resource} rows={filtered[resource]||[]} onAdd={()=>setModal({resource})} onDelete={id=>deleteRecord(resource,id)} loading={loading}/>)}
          </section>}
        <footer className="footer"><span>TextileFlow Operations Console</span><span><span className="pulse-dot"/> Connected architecture: React <b>→</b> FastAPI <b>→</b> MongoDB</span><a href={`${API}/docs`} target="_blank" rel="noreferrer">Open API docs ↗</a></footer>
      </div>
    </main>
    {modal && <RecordModal resource={modal.resource} onClose={()=>setModal(null)} onSubmit={payload=>submitRecord(modal.resource,payload)}/>}
    {toast && <div className="toast"><CheckCircle2 size={18}/><span>{toast}</span><button onClick={()=>setToast('')}><X size={15}/></button></div>}
  </div>
}

function Dashboard({dashboard,data,loading,onNavigate,onAdd}) {
  const k = dashboard?.kpis || {}
  const stats = [
    {label:'Active vendors',value:k.vendors,icon:Building2,meta:'Supplier network',tone:'blue',target:'vendors'},
    {label:'Raw material SKUs',value:k.materials,icon:Boxes,meta:`${dashboard?.low_stock?.length||0} items need attention`,tone:'purple',target:'vendors'},
    {label:'Production batches',value:k.production_batches,icon:Factory,meta:`${fmt(k.production_meters)} m total output`,tone:'orange',target:'production'},
    {label:'Team members',value:k.employees,icon:Users,meta:'Across shifts and units',tone:'green',target:'employees'},
  ]
  const prod = (data.production||[]).slice(0,6).map((x,i)=>({batch:x.batch_code,meters:Number(x.quantity_meters||0),status:x.status,unit:x.unit_name}))
  const warehouse = (data.warehouses||[]).map(w=>({name:w.name,stock:Number(w.stock_meters||0),capacity:Number(w.capacity_meters||0),percent:w.capacity_meters?Math.round(w.stock_meters/w.capacity_meters*100):0}))
  return <div className="dashboard">
    <div className="stats-grid">{stats.map(s=><button className="stat-card" key={s.label} onClick={()=>onNavigate(s.target)}><div className="stat-top"><span>{s.label}</span><span className={`stat-icon ${s.tone}`}><s.icon size={19}/></span></div><div className="stat-value">{loading?'—':fmt(s.value)}</div><div className="stat-foot"><span className="stat-meta">{s.meta}</span><ArrowUpRight size={15}/></div></button>)}</div>
    <div className="overview-grid">
      <section className="panel production-panel"><div className="panel-heading"><div><h2>Production pipeline</h2><p>Output volume by active batch</p></div><button className="text-link" onClick={()=>onNavigate('production')}>View batches <ArrowUpRight size={14}/></button></div>
        {prod.length ? <div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><BarChart data={prod} margin={{top:10,right:6,left:-20,bottom:0}}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e9edf4"/><XAxis dataKey="batch" tick={{fontSize:10,fill:'#7b879b'}} axisLine={false} tickLine={false}/><YAxis tick={{fontSize:10,fill:'#7b879b'}} axisLine={false} tickLine={false}/><Tooltip cursor={{fill:'#f3f6fb'}} formatter={v=>[`${fmt(v)} m`,'Output']}/><Bar dataKey="meters" fill="#4668e8" radius={[5,5,0,0]} maxBarSize={34}/></BarChart></ResponsiveContainer></div> : <EmptyState text="Production batches will appear here."/>}
        <div className="chart-legend"><span><i className="legend-blue"/> Output quantity (meters)</span><span className="legend-note">Live from MongoDB</span></div>
      </section>
      <section className="panel inventory-panel"><div className="panel-heading"><div><h2>Inventory health</h2><p>Raw material stock levels</p></div><button className="icon-btn light" onClick={()=>onNavigate('vendors')}><ArrowUpRight size={16}/></button></div>
        {(data.materials||[]).slice(0,4).map((m,i)=>{const pct=m.reorder_level?Math.min(100,Math.round(m.quantity/(m.reorder_level*2)*100)):100; const low=Number(m.quantity)<=Number(m.reorder_level); return <div className="inventory-item" key={m.id||i}><div className="inventory-title"><span>{m.name}</span><strong>{fmt(m.quantity)} <small>{m.unit}</small></strong></div><div className="progress-track"><div className={`progress-fill ${low?'low':''}`} style={{width:`${pct}%`}}/></div><div className="inventory-sub"><span>{m.vendor}</span><span className={low?'warning-text':''}>{low?'Below reorder level':`${pct}% stock indicator`}</span></div></div>})}
        {!data.materials?.length&&<EmptyState text="No material records yet."/>}
      </section>
    </div>
    <div className="overview-grid lower-grid">
      <section className="panel"><div className="panel-heading"><div><h2>Warehouse capacity</h2><p>Finished-goods storage utilization</p></div><button className="text-link" onClick={()=>onNavigate('warehouses')}>Manage <ArrowUpRight size={14}/></button></div>
        <div className="warehouse-summary"><div><span>Combined stock</span><strong>{fmt(k.warehouse_stock_meters)} <small>m</small></strong></div><div className="utilization-ring" style={{'--progress':`${dashboard?.warehouse_utilization||0}%`}}><div><strong>{dashboard?.warehouse_utilization||0}%</strong><span>utilized</span></div></div></div>
        {warehouse.map((w,i)=><div className="warehouse-row" key={i}><div className="warehouse-name"><Warehouse size={16}/><span>{w.name}</span><strong>{w.percent}%</strong></div><div className="progress-track"><div className="progress-fill" style={{width:`${Math.min(w.percent,100)}%`}}/></div><div className="warehouse-sub">{fmt(w.stock)} m stored of {fmt(w.capacity)} m capacity</div></div>)}
      </section>
      <section className="panel activity-panel"><div className="panel-heading"><div><h2>Distribution network</h2><p>Downstream supply chain coverage</p></div><button className="text-link" onClick={()=>onNavigate('network')}>View network <ArrowUpRight size={14}/></button></div>
        <div className="network-stats"><div className="network-stat"><span className="network-icon violet"><Truck size={18}/></span><div><strong>{fmt(k.distributors)}</strong><span>Distributors</span></div></div><div className="network-stat"><span className="network-icon cyan"><Building2 size={18}/></span><div><strong>{fmt(k.retailers)}</strong><span>Retail outlets</span></div></div></div>
        <div className="network-cities"><span>Recent retail locations</span>{(data.retailers||[]).slice(0,4).map((r,i)=><div key={r.id||i} className="city-row"><span className="city-dot">{r.city?.slice(0,1)||'C'}</span><div><strong>{r.city}</strong><small>{r.name}</small></div><span className="city-arrow">↗</span></div>)}{!data.retailers?.length&&<EmptyState text="Add retailers to see city coverage."/>}</div>
      </section>
    </div>
    <div className="quick-actions"><div><h2>Quick actions</h2><p>Create a record and watch the dashboard update in real time.</p></div><div className="quick-buttons"><button className="quick-action" onClick={()=>onAdd('vendors')}><span className="quick-icon blue"><Building2 size={17}/></span><span><strong>Add vendor</strong><small>Register a supplier</small></span><Plus size={16}/></button><button className="quick-action" onClick={()=>onAdd('production')}><span className="quick-icon orange"><Factory size={17}/></span><span><strong>New batch</strong><small>Log production</small></span><Plus size={16}/></button><button className="quick-action" onClick={()=>onAdd('materials')}><span className="quick-icon purple"><Boxes size={17}/></span><span><strong>Record material</strong><small>Update inventory</small></span><Plus size={16}/></button></div></div>
  </div>
}

function DataTable({resource,rows,onAdd,onDelete,loading}) {
  const conf=resources[resource]
  const columns=conf.fields.map(f=>f[0]).slice(0,5)
  return <div className="table-card"><div className="table-card-heading"><div className="table-title-icon"><conf.icon size={17}/></div><div><h3>{conf.title}</h3><p>{rows.length} {rows.length===1?'record':'records'} · stored in MongoDB</p></div><button className="btn btn-outline compact" onClick={onAdd}><Plus size={15}/> Add {conf.singular}</button></div>
    <div className="table-scroll"><table><thead><tr>{columns.map(c=><th key={c}>{pretty(c)}</th>)}<th>Status</th><th className="actions-head">Action</th></tr></thead><tbody>
      {loading?<tr><td colSpan={columns.length+2} className="empty-cell"><LoaderCircle className="spin" size={18}/> Loading records…</td></tr>:rows.length===0?<tr><td colSpan={columns.length+2} className="empty-cell">No matching records. Use “Add {conf.singular}” to create one.</td></tr>:rows.map(row=><tr key={row.id}>{columns.map(c=><td key={c} title={String(row[c]??'—')}>{c==='quantity'||c==='quantity_meters'||c==='stock_meters'||c==='capacity_meters'?fmt(row[c]):row[c]??'—'}</td>)}<td><StatusPill value={row.status || (resource==='materials' && Number(row.quantity)<=Number(row.reorder_level)?'Low Stock':'Active')} low={resource==='materials'&&Number(row.quantity)<=Number(row.reorder_level)}/></td><td><button className="delete-btn" title="Delete record" onClick={()=>onDelete(row.id)}><Trash2 size={15}/></button></td></tr>)}
    </tbody></table></div>
  </div>
}
function StatusPill({value,low}) {
  let cls=low?'warning':String(value).toLowerCase().replaceAll(' ','-')
  if(['completed','active'].includes(String(value).toLowerCase())) cls='success'
  if(['in-progress'].includes(cls)) cls='progress'
  if(['queued','on-hold'].includes(cls)) cls='neutral'
  return <span className={`status-pill ${cls}`}>{value}</span>
}
function EmptyState({text}) { return <div className="empty-state"><CircleHelp size={20}/><span>{text}</span></div> }

function RecordModal({resource,onClose,onSubmit}) {
  const conf=resources[resource]
  const [values,setValues]=useState({})
  const [saving,setSaving]=useState(false)
  const [error,setError]=useState('')
  const update=(key,value)=>setValues(v=>({...v,[key]:value}))
  const submit=async e=>{
    e.preventDefault(); setError('')
    const payload={}
    conf.fields.forEach(([key,,type])=>{ if(values[key]!==undefined && values[key]!== '') payload[key]=type==='number'?Number(values[key]):values[key] })
    const missing=conf.fields.filter(([key,label])=>!String(payload[key]??'').trim()).map(([,label])=>label)
    if(missing.length){setError(`Complete required fields: ${missing.join(', ')}`);return}
    setSaving(true)
    try { await onSubmit(payload) } finally { setSaving(false) }
  }
  return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}><section className="modal"><div className="modal-header"><div><span className="eyebrow">DATABASE ENTRY</span><h2>Add {conf.singular}</h2><p>This record will be sent to the API and saved in MongoDB.</p></div><button className="icon-btn light" onClick={onClose}><X size={18}/></button></div>
    <form onSubmit={submit}><div className="form-grid">{conf.fields.map(([key,label,type,options])=><label className="form-field" key={key}><span>{label}<b>*</b></span>{type==='select'?<select required value={values[key]||''} onChange={e=>update(key,e.target.value)}><option value="" disabled>Select {label.toLowerCase()}</option>{options.map(o=><option key={o}>{o}</option>)}</select>:<input required type={type} min={type==='number'?'0':undefined} step={type==='number'?'any':undefined} placeholder={`Enter ${label.toLowerCase()}`} value={values[key]??''} onChange={e=>update(key,e.target.value)}/>}</label>)}</div>
      {error&&<div className="form-error"><AlertTriangle size={15}/>{error}</div>}<div className="modal-footer"><div className="secure-note"><Database size={14}/> Persisted to MongoDB</div><div><button type="button" className="btn btn-outline" onClick={onClose}>Cancel</button><button className="btn btn-primary" disabled={saving}>{saving?<><LoaderCircle size={16} className="spin"/> Saving…</>:<><FilePlus2 size={16}/> Save record</>}</button></div></div>
    </form>
  </section></div>
}
export default App
