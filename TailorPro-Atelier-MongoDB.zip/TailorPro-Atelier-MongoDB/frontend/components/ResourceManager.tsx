'use client';

import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { AlertCircle, CheckCircle2, Edit2, Plus, RefreshCw, Search, Trash2, X } from 'lucide-react';
import { api } from '../lib/api';
import type { ColumnConfig, FieldConfig, ResourceConfig } from '../lib/resources';

type Row = Record<string, unknown>;
type ResourceManagerProps = { config: ResourceConfig };
type SourceRows = Record<string, Row[]>;

function emptyForm(config: ResourceConfig): Row {
  return Object.fromEntries(config.fields.map(field => [field.key, '']));
}

function asInputValue(value: unknown, type?: FieldConfig['type']): string {
  if (value === null || value === undefined) return '';
  if (type === 'datetime') {
    const raw = String(value);
    return raw.includes('T') ? raw.slice(0, 16) : raw;
  }
  if (type === 'date') return String(value).slice(0, 10);
  return String(value);
}

function formatCell(value: unknown, column: ColumnConfig): string {
  if (value === null || value === undefined || value === '') return '—';
  if (column.format === 'date') {
    const d = new Date(String(value) + (String(value).length === 10 ? 'T00:00:00' : ''));
    return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  }
  if (column.format === 'datetime') {
    const d = new Date(String(value));
    return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  }
  if (column.format === 'money') return `₹${Number(value).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
  if (column.prefix) return `${column.prefix}${String(value).padStart(4, '0')}`;
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

function itemPath(config: ResourceConfig, row: Row): string {
  const keys = config.keyFields || [config.idKey || `${config.key.replace(/s$/, '')}_id`];
  return `${config.endpoint}/${keys.map(key => encodeURIComponent(String(row[key]))).join('/')}`;
}

export default function ResourceManager({ config }: ResourceManagerProps) {
  const [rows, setRows] = useState<Row[]>([]);
  const [sourceRows, setSourceRows] = useState<SourceRows>({});
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<Row | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState<Row>(() => emptyForm(config));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const endpoints = config.sources || [];
      const [main, ...sources] = await Promise.all([
        api<Row[]>(config.endpoint),
        ...endpoints.map(source => api<Row[]>(source.endpoint)),
      ]);
      setRows(main);
      const next: SourceRows = {};
      endpoints.forEach((source, index) => { next[source.key] = sources[index] || []; });
      setSourceRows(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : `Could not load ${config.title.toLowerCase()}. Check that the API is running.`);
    } finally {
      setLoading(false);
    }
  }, [config]);

  useEffect(() => { void load(); }, [load]);

  const filteredRows = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter(row => config.columns.some(column => {
      const raw = row[column.key];
      if (column.lookup && raw !== null && raw !== undefined) {
        const source = (config.sources || []).find(s => s.key === column.lookup);
        const match = sourceRows[column.lookup]?.find(x => String(x[source?.idKey || 'id']) === String(raw));
        if (match && String(match[source?.labelKey || 'name'] ?? '').toLowerCase().includes(q)) return true;
      }
      return String(raw ?? '').toLowerCase().includes(q);
    }));
  }, [query, rows, config, sourceRows]);

  function startCreate() {
    setEditing(null);
    setForm(emptyForm(config));
    setFormOpen(true);
    setError(''); setNotice('');
  }

  function startEdit(row: Row) {
    setEditing(row);
    setFormOpen(true);
    const next: Row = {};
    config.fields.forEach(field => { next[field.key] = asInputValue(row[field.key], field.type); });
    setForm(next);
    setError(''); setNotice('');
  }

  function cancelForm() {
    setEditing(null); setFormOpen(false); setForm(emptyForm(config)); setError('');
  }

  function fieldValue(field: FieldConfig, raw: unknown): unknown {
    const value = String(raw ?? '').trim();
    if (!value) return null;
    if (field.type === 'number') return Number(value);
    if (field.type === 'select' && field.source) return Number(value);
    return value;
  }

  async function submitForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true); setError(''); setNotice('');
    const payload: Row = {};
    for (const field of config.fields) payload[field.key] = fieldValue(field, form[field.key]);
    try {
      if (editing) await api(itemPath(config, editing), { method: 'PUT', body: JSON.stringify(payload) });
      else await api(config.endpoint, { method: 'POST', body: JSON.stringify(payload) });
      setNotice(editing ? `${config.singular} updated successfully.` : `${config.singular} created successfully.`);
      setEditing(null); setFormOpen(false); setForm(emptyForm(config));
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : `Could not save this ${config.singular}.`);
    } finally {
      setSaving(false);
    }
  }

  async function removeRow(row: Row) {
    const identity = (config.keyFields || [config.idKey || `${config.key.replace(/s$/, '')}_id`]).map(key => row[key]).join(' / ');
    if (!window.confirm(`Delete ${config.singular} ${identity}? This cannot be undone.`)) return;
    setError(''); setNotice('');
    try {
      await api(itemPath(config, row), { method: 'DELETE' });
      setNotice(`${config.singular} deleted.`);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : `Could not delete this ${config.singular}. It may be referenced by other records.`);
    }
  }

  function renderCell(row: Row, column: ColumnConfig) {
    const raw = row[column.key];
    let value: unknown = raw;
    if (column.lookup && raw !== null && raw !== undefined) {
      const source = (config.sources || []).find(s => s.key === column.lookup);
      const match = sourceRows[column.lookup]?.find(x => String(x[source?.idKey || 'id']) === String(raw));
      if (match && source) {
        const label = match[source.labelKey];
        value = source.prefix ? `${source.prefix}${String(label).padStart(4, '0')}` : label;
      }
    }
    const shown = formatCell(value, column);
    if (column.format === 'status') {
      const lower = String(raw ?? '').toLowerCase();
      const cls = lower.includes('deliver') || lower.includes('complete') || lower.includes('approved') ? 'green'
        : lower.includes('adjust') || lower.includes('trial') || lower.includes('ready') ? 'gold'
        : lower.includes('process') || lower.includes('stitch') || lower.includes('dispatch') ? 'blue'
        : lower.includes('pending') || lower.includes('cancel') ? 'red' : 'gray';
      return <span className={`pill ${cls}`}>{shown}</span>;
    }
    const isEmphasis = column.key === 'name' || column.key === 'style_name' || column.key.endsWith('_id') && !column.lookup;
    return isEmphasis ? <b>{shown}</b> : shown;
  }

  return <div className="content">
    <div className="page-title">
      <div><div className="eyebrow">{config.eyebrow}</div><h2>{config.title}</h2><p>{config.description}</p></div>
      <button className="btn btn-primary" onClick={startCreate}><Plus size={14}/> Add {config.singular}</button>
    </div>

    {notice && <div className="resource-alert success"><CheckCircle2 size={15}/><span>{notice}</span><button aria-label="Dismiss message" onClick={() => setNotice('')}><X size={14}/></button></div>}
    {error && <div className="resource-alert danger"><AlertCircle size={15}/><span>{error}</span><button aria-label="Dismiss error" onClick={() => setError('')}><X size={14}/></button></div>}

    {formOpen && <section className="card form-card resource-form" style={{ marginBottom: 18 }}>
      <div className="resource-form-head"><div><h3>{editing ? `Edit ${config.singular}` : `New ${config.singular}`}</h3><span>Changes are saved directly to the application database.</span></div><button type="button" className="iconbtn" onClick={cancelForm} aria-label="Close form"><X size={15}/></button></div>
      <form onSubmit={submitForm}>
        <div className="form-grid">
          {config.fields.map(field => {
            const isKey = (config.keyFields || []).includes(field.key);
            const disabled = Boolean(editing && isKey);
            const value = String(form[field.key] ?? '');
            return <div className={`field ${field.type === 'textarea' ? 'span2' : ''}`} key={field.key}>
              <label htmlFor={`${config.key}-${field.key}`}>{field.label}{field.required ? ' *' : ''}</label>
              {field.type === 'select' ? <select id={`${config.key}-${field.key}`} required={field.required} disabled={disabled} value={value} onChange={e => setForm(old => ({ ...old, [field.key]: e.target.value }))}>
                <option value="">Select {field.label.toLowerCase()}</option>
                {(field.options || []).map(option => <option key={option} value={option}>{option}</option>)}
                {field.source && (sourceRows[field.source] || []).map(option => {
                  const source = (config.sources || []).find(s => s.key === field.source);
                  if (!source) return null;
                  const optionValue = option[source.idKey];
                  const rawLabel = option[source.labelKey];
                  const label = source.prefix ? `${source.prefix}${String(rawLabel).padStart(4, '0')}` : String(rawLabel ?? optionValue);
                  return <option key={String(optionValue)} value={String(optionValue)}>{label}</option>;
                })}
              </select> : field.type === 'textarea' ? <textarea id={`${config.key}-${field.key}`} required={field.required} value={value} onChange={e => setForm(old => ({ ...old, [field.key]: e.target.value }))} />
                : <input id={`${config.key}-${field.key}`} type={field.type === 'datetime' ? 'datetime-local' : field.type || 'text'} step={field.step} required={field.required} disabled={disabled} value={value} onChange={e => setForm(old => ({ ...old, [field.key]: e.target.value }))} />}
              {field.help && <small>{field.help}</small>}
            </div>;
          })}
        </div>
        <div className="form-actions"><button type="button" className="btn btn-light" onClick={cancelForm}>Cancel</button><button className="btn btn-primary" type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Save changes' : `Create ${config.singular}`}</button></div>
      </form>
    </section>}

    <div className="toolbar"><div className="search"><Search size={14}/><input placeholder={`Search ${config.title.toLowerCase()}…`} value={query} onChange={e => setQuery(e.target.value)}/></div><span className="pill gray">{filteredRows.length} of {rows.length} records</span><button className="btn btn-light refresh-btn" onClick={() => void load()} disabled={loading}><RefreshCw size={13}/> Refresh</button></div>
    <section className="panel">
      {loading ? <div className="empty"><RefreshCw size={18} className="spin"/><div style={{ marginTop: 10 }}>Loading {config.title.toLowerCase()} from MongoDB…</div></div> : <div className="table-wrap"><table className="table"><thead><tr>{config.columns.map(column => <th key={column.key}>{column.label}</th>)}<th className="actions-col">Actions</th></tr></thead><tbody>
        {filteredRows.map((row, index) => <tr key={(config.keyFields || [config.idKey || 'id']).map(key => String(row[key])).join('-') || index}>{config.columns.map(column => <td key={column.key}>{renderCell(row, column)}</td>)}<td className="row-actions"><button className="iconbtn small-icon" title="Edit record" onClick={() => startEdit(row)}><Edit2 size={13}/></button><button className="iconbtn small-icon delete-icon" title="Delete record" onClick={() => void removeRow(row)}><Trash2 size={13}/></button></td></tr>)}
      </tbody></table>{!filteredRows.length && <div className="empty">{error ? 'Records could not be loaded. Fix the connection and refresh.' : query ? 'No records match your search.' : `No ${config.title.toLowerCase()} yet. Use “Add ${config.singular}” to create the first record.`}</div>}</div>}
    </section>
    <div className="resource-foot">Live MongoDB data <span>•</span> {config.columns.length} fields shown <span>•</span> Create, edit and delete</div>
  </div>;
}

