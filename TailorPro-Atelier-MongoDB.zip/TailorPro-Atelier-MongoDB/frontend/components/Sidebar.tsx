'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Users, Ruler, Palette, ShoppingBag, Scissors, Shirt, Gem, Truck, CalendarDays, Building2, Settings2, UsersRound, Package, Layers3, Database } from 'lucide-react';

const groups = [
  { label:'Overview', items:[['/dashboard','Dashboard',LayoutDashboard]] },
  { label:'Atelier', items:[
    ['/customers','Customers',Users],
    ['/measurements','Measurements',Ruler],
    ['/designers','Designers',UsersRound],
    ['/designs','Designs',Palette],
    ['/orders','Orders',ShoppingBag],
    ['/production','Production board',Scissors],
    ['/garments','Garments',Package],
    ['/tailors','Tailors',Shirt],
  ]},
  { label:'Inventory & Fulfilment', items:[
    ['/fabrics','Fabrics',Gem],
    ['/garment-fabrics','Fabric usage',Layers3],
    ['/suppliers','Suppliers',Building2],
    ['/trials','Trials',CalendarDays],
    ['/deliveries','Deliveries',Truck],
  ]},
  { label:'Workspace', items:[['/database','Database explorer',Database],['/settings','Settings',Settings2]] },
] as const;

export default function Sidebar(){
  const pathname = usePathname();
  return <aside className="sidebar">
    <div className="brand">
      <div className="brandmark">T</div>
      <div><h1>TailorPro</h1><span>Atelier management</span></div>
    </div>
    <nav className="nav">
      {groups.map(group => <div key={group.label}>
        <div className="nav-label">{group.label}</div>
        {group.items.map(([href,label,Icon]) => <Link key={href} href={href} className={pathname===href ? 'active':''}><Icon size={15}/><span>{label}</span></Link>)}
      </div>)}
    </nav>
    <div className="side-note"><b>Atelier mode</b><span>Your workspace is connected to MongoDB and FastAPI.</span></div>
  </aside>
}
