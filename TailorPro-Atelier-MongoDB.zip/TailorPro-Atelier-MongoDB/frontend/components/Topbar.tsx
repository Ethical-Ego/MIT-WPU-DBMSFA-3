'use client';
import { Bell, ChevronDown, Sparkles } from 'lucide-react';
import { usePathname } from 'next/navigation';

const names:Record<string,string>={
  '/dashboard':'Dashboard','/customers':'Customers','/measurements':'Measurements','/designs':'Designs','/orders':'Orders','/production':'Production','/tailors':'Tailors','/fabrics':'Fabrics','/suppliers':'Suppliers','/trials':'Trials','/deliveries':'Deliveries','/settings':'Settings'
};
export default function Topbar(){
 const path=usePathname();
 return <header className="topbar">
   <div className="crumb">Atelier / <b style={{color:'#4f5a6b'}}>{names[path] || 'Dashboard'}</b></div>
   <div className="top-actions">
     <div className="iconbtn"><Sparkles size={15}/></div>
     <div className="iconbtn"><Bell size={15}/></div>
     <div className="profile"><div className="avatar">PN</div><div><b>Studio Admin</b><small>TailorPro Atelier</small></div><ChevronDown size={13} color="#8a93a1"/></div>
   </div>
 </header>
}
