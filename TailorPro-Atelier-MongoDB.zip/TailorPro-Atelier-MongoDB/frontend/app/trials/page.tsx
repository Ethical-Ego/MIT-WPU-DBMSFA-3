import ResourceManager from '../../components/ResourceManager';
import { resources } from '../../lib/resources';

export default function Page() {
  return <ResourceManager config={resources.trials} />;
}
