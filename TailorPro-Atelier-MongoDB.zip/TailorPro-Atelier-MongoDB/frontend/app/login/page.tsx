'use client';
import { useState } from 'react';
import { ArrowRight, Eye, EyeOff, Sparkles } from 'lucide-react';
export default function Login(){
 const [show,setShow]=useState(false); const [loading,setLoading]=useState(false);
 const submit=(e:React.FormEvent)=>{e.preventDefault();setLoading(true);setTimeout(()=>{window.location.href='/dashboard'},450)};
 return <div style={{minHeight:'100vh',display:'grid',placeItems:'center',background:'linear-gradient(135deg,#17283f,#2b4059)'}}><div style={{width:'min(430px,calc(100% - 32px))',background:'#fff',borderRadius:22,padding:34,boxShadow:'0 30px 70px rgba(0,0,0,.22)'}}>
  <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:24}}><div className="brandmark">T</div><div><div style={{fontFamily:'Playfair Display,serif',fontSize:22,fontWeight:700}}>TailorPro</div><div style={{fontSize:9,letterSpacing:1.8,textTransform:'uppercase',color:'#9a7a4e'}}>Atelier management</div></div></div>
  <div className="eyebrow">Welcome back</div><h2 style={{fontFamily:'Playfair Display,serif',fontSize:31,margin:'5px 0 8px'}}>Enter the atelier.</h2><p style={{fontSize:12,color:'#808998',lineHeight:1.6}}>Sign in to manage customers, orders, fittings and deliveries.</p>
  <form onSubmit={submit} className="form-grid" style={{padding:0,marginTop:20}}><div className="field span2"><label>Email</label><input defaultValue="admin@tailorpro.local" type="email" required /></div><div className="field span2"><label>Password</label><div style={{position:'relative'}}><input defaultValue="tailorpro" type={show?'text':'password'} required style={{width:'100%',paddingRight:38}}/><button type="button" onClick={()=>setShow(!show)} style={{position:'absolute',right:9,top:8,border:0,background:'transparent',color:'#8c95a2',cursor:'pointer'}}>{show?<EyeOff size={14}/>:<Eye size={14}/>}</button></div></div><button className="btn btn-primary span2" disabled={loading}>{loading?'Opening atelier…':'Sign in'} {!loading&&<ArrowRight size={14}/>}</button></form>
  <div style={{marginTop:16,padding:'10px 12px',borderRadius:11,background:'#f7f3ed',fontSize:9,color:'#8b765d',display:'flex',gap:7,alignItems:'center'}}><Sparkles size={12}/> Demo account is prefilled for local development.</div>
 </div></div>
}
