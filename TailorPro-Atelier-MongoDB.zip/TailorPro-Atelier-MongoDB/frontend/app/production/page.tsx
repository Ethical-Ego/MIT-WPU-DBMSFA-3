'use client';
import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { AlertCircle, ArrowUpRight, RefreshCw } from 'lucide-react';
import { api } from '../../lib/api';
import type { Production } from '../../types';

const columns = ['Pending', 'Stitching', 'Trial', 'Completed'];
export default function Production() {
  const [rows, setRows] = useState<Production[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const load = useCallback(() => {
    setLoading(true); setError('');
    api<Production[]>('/production').then(setRows).catch(e => setError(e instanceof Error ? e.message : 'Could not load production.')).finally(() => setLoading(false));
  }, []);
  useEffect(() => { load(); }, [load]);
  return <div className="content"><div className="page-title"><div><div className="eyebrow">Workshop</div><h2>Production board</h2><p>A visual flow of every garment moving through the atelier.</p></div><div className="title-actions"><button className="btn btn-light" onClick={load} disabled={loading}><RefreshCw size={13}/> Refresh</button><Link className="btn btn-primary" href="/garments">Manage garment records <ArrowUpRight size={14}/></Link></div></div>
    {error && <div className="resource-alert danger"><AlertCircle size={15}/><span>{error}</span></div>}
    {loading ? <div className="empty"><RefreshCw size={18} className="spin"/><div style={{ marginTop: 10 }}>Loading production from MongoDB…</div></div> : <div className="grid kanban">{columns.map(column => { const list = rows.filter(item => item.status === column); return <section key={column} className="kanban-col"><div className="kanban-title"><span>{column}</span><span className="pill gray">{list.length}</span></div>{list.map(item => <article className="task" key={item.garment_id}><b>ORD-{String(item.order_id).padStart(4, '0')}</b><p>{item.style}</p><div className="task-foot"><span>{item.customer}</span><span>{item.tailor}</span></div></article>)}{!list.length && <div style={{ padding: '25px 10px', textAlign: 'center', fontSize: 9, color: '#98a0ac' }}>Nothing here yet</div>}</section>; })}</div>}
    <div className="resource-foot">This board reflects garment stitching status. Use “Manage garment records” to create garments or change their status.</div>
  </div>;
}
