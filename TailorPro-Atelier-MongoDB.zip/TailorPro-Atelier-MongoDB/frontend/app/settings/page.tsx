'use client';
import { useEffect, useState } from 'react';
import { AlertCircle, CheckCircle2, Database, ShieldCheck, Sparkles } from 'lucide-react';
import { getApiHealth, type ApiHealth } from '../../lib/api';

type Preferences = { studioName: string; currency: string; location: string; unit: string };
const defaults: Preferences = { studioName: 'TailorPro Atelier', currency: 'INR', location: 'Pune, Maharashtra', unit: 'inch' };

export default function Settings() {
  const [saved, setSaved] = useState(false);
  const [preferences, setPreferences] = useState<Preferences>(defaults);
  const [health, setHealth] = useState<ApiHealth | null>(null);
  const [healthError, setHealthError] = useState('');
  useEffect(() => {
    try {
      const raw = localStorage.getItem('tailorpro-preferences');
      if (raw) setPreferences({ ...defaults, ...JSON.parse(raw) as Partial<Preferences> });
    } catch { /* Ignore unavailable/corrupt local preferences and use defaults. */ }
    getApiHealth().then(setHealth).catch(e => setHealthError(e instanceof Error ? e.message : 'Health check failed.'));
  }, []);
  function save() {
    try {
      localStorage.setItem('tailorpro-preferences', JSON.stringify(preferences));
      setSaved(true);
      window.setTimeout(() => setSaved(false), 1800);
    } catch {
      setHealthError('Could not save preferences in this browser.');
    }
  }
  const connected = Boolean(health && health.status === 'ok' && health.database === 'connected');
  return <div className="content"><div className="page-title"><div><div className="eyebrow">Workspace</div><h2>Settings</h2><p>Studio preferences and live application health.</p></div></div>
    {healthError && <div className="resource-alert danger"><AlertCircle size={15}/><span>{healthError}</span></div>}
    <div className="grid cols"><section className="card form-card"><div className="card-head" style={{ padding: '0 0 17px' }}><div><h3>Studio profile</h3><span>Preferences saved in this browser.</span></div></div>
      <div className="form-grid" style={{ padding: 0 }}>
        <div className="field"><label>Studio name</label><input value={preferences.studioName} onChange={e => setPreferences({ ...preferences, studioName: e.target.value })}/></div>
        <div className="field"><label>Currency</label><select value={preferences.currency} onChange={e => setPreferences({ ...preferences, currency: e.target.value })}><option value="INR">INR — Indian Rupee</option><option value="USD">USD — US Dollar</option></select></div>
        <div className="field"><label>Default location</label><input value={preferences.location} onChange={e => setPreferences({ ...preferences, location: e.target.value })}/></div>
        <div className="field"><label>Measurement unit</label><select value={preferences.unit} onChange={e => setPreferences({ ...preferences, unit: e.target.value })}><option value="inch">Inches</option><option value="cm">Centimetres</option></select></div>
      </div><div className="form-actions"><button className="btn btn-primary" onClick={save}>{saved ? <><CheckCircle2 size={14}/> Saved</> : 'Save preferences'}</button></div>
    </section><section className="card" style={{ padding: 20 }}><div className="card-head" style={{ padding: '0 0 15px' }}><div><h3>System health</h3><span>Live checks against the API and database</span></div></div>
      <Health icon={<Database size={16}/>} label="MongoDB database" value={health ? health.database : healthError ? 'Unreachable' : 'Checking…'} ok={connected}/>
      <Health icon={<ShieldCheck size={16}/>} label="FastAPI backend" value={health ? health.status : healthError ? 'Unavailable' : 'Checking…'} ok={connected}/>
      <Health icon={<Sparkles size={16}/>} label="Next.js frontend" value="Loaded" ok/>
      {health && <div className="health-counts">DB sample counts: {health.counts?.customers ?? 0} customers · {health.counts?.designs ?? 0} designs · {health.counts?.orders ?? 0} orders</div>}
    </section></div>
  </div>;
}
function Health({ icon, label, value, ok }: { icon: React.ReactNode; label: string; value: string; ok?: boolean }) { return <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, padding: '13px 0', borderTop: '1px solid #eef0f4' }}><div className="person"><div className="mini-avatar">{icon}</div><div><b style={{ fontSize: 11 }}>{label}</b><div style={{ fontSize: 9, color: '#929aa6' }}>Service</div></div></div><span className={`pill ${ok ? 'green' : value === 'Checking…' ? 'gray' : 'red'}`}>{value}</span></div> }
