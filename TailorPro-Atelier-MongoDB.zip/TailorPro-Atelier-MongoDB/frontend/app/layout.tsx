import './globals.css';
import Sidebar from '../components/Sidebar';
import Topbar from '../components/Topbar';

export const metadata = { title:'TailorPro Atelier', description:'Custom garment management system' };

export default function RootLayout({children}:{children:React.ReactNode}){
 return <html lang="en"><body><div className="shell"><Sidebar/><main className="main"><Topbar/>{children}</main></div></body></html>;
}
