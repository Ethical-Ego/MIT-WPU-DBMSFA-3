'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { AlertCircle, ArrowUpRight, CalendarDays, Clock3, Plus, RefreshCw, Scissors, ShoppingBag, Users } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { api } from '../../lib/api';
import type { Customer, Dashboard, Order } from '../../types';

const initial:Dashboard={customers:0,orders:0,garments:0,trials:0,deliveries:0,order_status:[]};
export default function DashboardPage(){
 const [data,setData]=useState(initial);
 const [orders,setOrders]=useState<Order[]>([]);
 const [customers,setCustomers]=useState<Customer[]>([]);
 const [error,setError]=useState('');
 const [loading,setLoading]=useState(true);
 const load=()=>{setLoading(true);setError('');Promise.all([api<Dashboard>('/dashboard'),api<Order[]>('/orders'),api<Customer[]>('/customers')]).then(([a,b,c])=>{setData(a);setOrders(b);setCustomers(c)}).catch(e=>setError(e instanceof Error?e.message:'Could not load dashboard data.')).finally(()=>setLoading(false));};
 useEffect(()=>{load()},[]);
 const chart=data.order_status;
 return <div className="content">
  <div className="page-title"><div><div className="eyebrow">Good morning, studio admin</div><h2>Atelier overview</h2><p>Everything happening across your custom garment studio, at a glance.</p></div><Link href="/orders" className="btn btn-primary"><Plus size={14}/> New order</Link></div>
  {error&&<div className="resource-alert danger"><AlertCircle size={15}/><span>{error}</span><button className="btn btn-light" onClick={load}><RefreshCw size={13}/> Retry</button></div>}
  <div className="grid stats"><Stat icon={<Users size={18}/>} value={data.customers} label="Total customers" note={loading?'Loading database…':'Live database count'}/><Stat icon={<ShoppingBag size={18}/>} value={data.orders} label="Total orders" note={loading?'Loading database…':'All recorded orders'}/><Stat icon={<Scissors size={18}/>} value={data.garments} label="In production" note="Pending, stitching or trial"/><Stat icon={<CalendarDays size={18}/>} value={data.trials} label="Upcoming trials" note="Scheduled in the future"/></div>
  <div className="grid cols">
   <section className="card"><div className="card-head"><div><h3>Order performance</h3><span>Current pipeline by status</span></div><span className="pill green">Live</span></div><div className="chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={chart} barSize={30}><CartesianGrid vertical={false} strokeDasharray="3 3" stroke="#edf0f4"/><XAxis dataKey="status" axisLine={false} tickLine={false} tick={{fontSize:9,fill:'#8791a2'}}/><YAxis axisLine={false} tickLine={false} tick={{fontSize:9,fill:'#8791a2'}} allowDecimals={false}/><Tooltip cursor={{fill:'#f6f7f9'}} contentStyle={{borderRadius:10,border:'1px solid #e6e9ee',fontSize:10}}/><Bar dataKey="count" radius={[6,6,0,0]} fill="#203551"/></BarChart></ResponsiveContainer></div></section>
   <section className="card"><div className="card-head"><div><h3>Atelier shortcuts</h3><span>Jump into your workflow</span></div></div><div className="quick"><Link href="/customers"><div><strong>New customer</strong><br/><span>Create a customer profile</span></div><ArrowUpRight size={14}/></Link><Link href="/production"><div><strong>Production board</strong><br/><span>Move garments through stages</span></div><ArrowUpRight size={14}/></Link><Link href="/trials"><div><strong>Trial calendar</strong><br/><span>Review upcoming fittings</span></div><ArrowUpRight size={14}/></Link><Link href="/deliveries"><div><strong>Delivery queue</strong><br/><span>Check ready-to-ship orders</span></div><ArrowUpRight size={14}/></Link></div></section>
  </div>
  <div className="grid cols">
    <section className="card"><div className="card-head"><div><h3>Recent orders</h3><span>Latest activity in your studio</span></div><Link href="/orders" className="pill blue">View all</Link></div><div className="table-wrap"><table className="table"><thead><tr><th>Order</th><th>Customer</th><th>Date</th><th>Status</th></tr></thead><tbody>{orders.slice(0,6).map(o=>{const c=customers.find(x=>x.customer_id===o.customer_id);return <tr key={o.order_id}><td><b>ORD-{String(o.order_id).padStart(4,'0')}</b></td><td><div className="person"><div className="mini-avatar">{c?.name?.split(' ').map(x=>x[0]).join('').slice(0,2)||'CU'}</div>{c?.name||`Customer #${o.customer_id}`}</div></td><td>{new Date(o.order_date).toLocaleDateString('en-IN',{day:'2-digit',month:'short'})}</td><td><Status s={o.status}/></td></tr>})}</tbody></table></div></section>
    <section className="card"><div className="card-head"><div><h3>Studio pulse</h3><span>Today’s focus</span></div><Clock3 size={17} color="#a27d4b"/></div><div style={{padding:'3px 20px 20px'}}><Pulse value={String(data.garments)} label="garments in active production"/><Pulse value={String(data.adjustments_needed??0)} label="fittings requiring alterations"/><Pulse value={String(data.ready_deliveries??0)} label="deliveries ready to dispatch" last/></div></section>
  </div>
  <div className="footer-note">TailorPro Atelier • Custom garment management • {loading?'Connecting to':'Connected to'} FastAPI + MongoDB</div>
 </div>
}
function Stat({icon,value,label,note}:{icon:React.ReactNode;value:number;label:string;note:string}){return <div className="stat"><div className="icon">{icon}</div><h3>{value}</h3><p>{label}</p><small>{note}</small></div>}
function Status({s}:{s:string}){const k=s.toLowerCase();const cls=k.includes('deliver')||k.includes('complete')?'green':k.includes('trial')?'gold':k.includes('process')?'blue':k.includes('pending')?'red':'gray';return <span className={`pill ${cls}`}>{s}</span>}
function Pulse({value,label,last}:{value:string;label:string;last?:boolean}){return <div style={{padding:'14px 0',borderBottom:last?'0':'1px solid #eef0f4'}}><b style={{fontSize:13}}>{value}</b><div style={{fontSize:10,color:'#7f8898',marginTop:3}}>{label}</div></div>}
