'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ArrowUpRight, Check, Clipboard, Database, RefreshCw, Table2 } from 'lucide-react';
import { api } from '../../lib/api';

type CollectionSummary = { table: string; collection?: string; label: string; endpoint: string; records: number };
type Summary = {
  database: string;
  database_name?: string;
  table_count: number;
  collection_count?: number;
  connection_hint?: string;
  tables: CollectionSummary[];
};

export default function DatabasePage() {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  const load = () => {
    setLoading(true);
    setError('');
    api<Summary>('/database-summary')
      .then(setSummary)
      .catch(e => setError(e instanceof Error ? e.message : 'Could not read the database summary.'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);
  const totalRecords = (summary?.tables || []).reduce((total, collection) => total + collection.records, 0);
  const mongoUri = summary?.connection_hint || 'mongodb://localhost:27018';

  async function copyUri() {
    try {
      await navigator.clipboard.writeText(mongoUri);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setError(`Copy unavailable. Use this connection string in Compass: ${mongoUri}`);
    }
  }

  return <div className="content">
    <div className="page-title">
      <div><div className="eyebrow">Data administration</div><h2>Database explorer</h2><p>Your ERD entities are stored as real MongoDB documents, not frontend mock data.</p></div>
      <button className="btn btn-primary" onClick={load} disabled={loading}><RefreshCw size={14} className={loading ? 'spin' : ''}/> Refresh counts</button>
    </div>
    {error && <div className="resource-alert danger">{error}</div>}

    <section className="card" style={{ padding: 21, marginBottom: 18, background: 'linear-gradient(115deg,#fff 0%,#fbf7f0 100%)' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 15, flexWrap: 'wrap', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: 13, flex: '1 1 320px' }}>
          <div style={{ width: 45, height: 45, flex: '0 0 45px', display: 'grid', placeItems: 'center', borderRadius: 13, color: '#fff', background: '#153d32' }}><Database size={21}/></div>
          <div>
            <div className="eyebrow">MongoDB Compass connection</div>
            <h3 style={{ margin: '4px 0 6px', fontSize: 17 }}>Open your actual database</h3>
            <p style={{ margin: 0, maxWidth: 640, color: 'var(--muted)', fontSize: 11, lineHeight: 1.7 }}>
              Open MongoDB Compass on your Mac, connect with the URI below, then open the <b>{summary?.database_name || 'tailorpro'}</b> database. You will see the collections and documents created by this app.
            </p>
          </div>
        </div>
        <span className={`pill ${error ? 'red' : loading ? 'gray' : 'green'}`}>{error ? 'Connection issue' : loading ? 'Checking connection' : 'MongoDB API connected'}</span>
      </div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap', marginTop: 18 }}>
        <code style={{ display: 'block', flex: '1 1 320px', padding: '12px 14px', borderRadius: 10, color: '#18314d', background: '#f0f2f5', border: '1px solid #e2e6ec', fontSize: 12, overflowWrap: 'anywhere' }}>{mongoUri}</code>
        <button className="btn btn-light" onClick={copyUri}>{copied ? <Check size={14}/> : <Clipboard size={14}/>} {copied ? 'Copied' : 'Copy URI'}</button>
      </div>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 13 }}>
        <span className="pill gray">Database: {summary?.database_name || 'tailorpro'}</span>
        <span className="pill gray">Engine: MongoDB 7</span>
        <span className="pill gray">Persistent Docker volume</span>
      </div>
    </section>

    <div className="grid stats database-stats">
      <div className="stat"><div className="icon"><Database size={18}/></div><h3>{summary?.collection_count ?? summary?.table_count ?? 12}</h3><p>ERD collections</p><small>{loading ? 'Checking database…' : 'All 12 ERD entities represented'}</small></div>
      <div className="stat"><div className="icon"><Table2 size={18}/></div><h3>{loading ? '…' : totalRecords.toLocaleString('en-IN')}</h3><p>Total documents</p><small>Across all ERD collections</small></div>
      <div className="stat"><div className="icon"><RefreshCw size={18}/></div><h3 style={{ fontSize: 23 }}>{loading ? '…' : error ? 'Offline' : 'Connected'}</h3><p>Database status</p><small>{error ? 'API check failed' : 'FastAPI ↔ MongoDB'}</small></div>
    </div>

    <div className="card-head" style={{ padding: '23px 0 3px' }}><div><h3 style={{ fontSize: 14 }}>ERD collections</h3><span>Choose a collection to manage its saved records in TailorPro.</span></div></div>
    <div className="database-grid">
      {(summary?.tables || []).map(collection => <Link href={collection.endpoint} key={collection.table} className="database-card">
        <div className="database-card-icon"><Table2 size={18}/></div>
        <div className="database-card-body"><span className="database-table-name">{collection.collection || collection.table}</span><strong>{collection.label}</strong><span>{collection.records.toLocaleString('en-IN')} {collection.records === 1 ? 'document' : 'documents'}</span></div>
        <ArrowUpRight size={15} className="database-arrow"/>
      </Link>)}
    </div>
    <p className="resource-foot">Changes from these screens are saved in MongoDB. Refresh this page to see live collection counts; use Compass to inspect each raw document and its ObjectId.</p>
  </div>;
}
