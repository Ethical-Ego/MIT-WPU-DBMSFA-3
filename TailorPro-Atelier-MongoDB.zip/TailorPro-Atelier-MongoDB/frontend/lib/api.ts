const BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';

export async function api<T>(path: string, options?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${BASE}${path}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...(options?.headers || {}) },
      cache: 'no-store',
    });
  } catch {
    throw new Error(`Cannot reach the TailorPro API at ${BASE}. Make sure Docker services are running, then refresh.`);
  }

  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    const body = await response.text();
    if (body) {
      try {
        const parsed = JSON.parse(body) as { detail?: unknown; message?: unknown };
        const detail = parsed.detail ?? parsed.message;
        message = typeof detail === 'string' ? detail : JSON.stringify(detail ?? parsed);
      } catch {
        message = body;
      }
    }
    throw new Error(message);
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

export type ApiHealth = { status: string; database: string; service: string; counts?: { customers: number; orders: number; designs: number } };
export const API_ORIGIN = new URL(BASE).origin;

export async function getApiHealth(): Promise<ApiHealth> {
  let response: Response;
  try {
    response = await fetch(`${API_ORIGIN}/health`, { cache: 'no-store' });
  } catch {
    throw new Error(`Cannot reach the TailorPro backend at ${API_ORIGIN}. Start the Docker services and try again.`);
  }
  if (!response.ok) throw new Error(`Backend health check failed (${response.status}).`);
  return response.json() as Promise<ApiHealth>;
}
