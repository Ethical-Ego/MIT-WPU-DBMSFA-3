export type SourceConfig = {
  key: string;
  endpoint: string;
  idKey: string;
  labelKey: string;
  prefix?: string;
};

export type FieldConfig = {
  key: string;
  label: string;
  type?: 'text' | 'number' | 'date' | 'datetime' | 'textarea' | 'select';
  required?: boolean;
  step?: string;
  source?: string;
  options?: string[];
  help?: string;
};

export type ColumnConfig = {
  key: string;
  label: string;
  format?: 'date' | 'datetime' | 'money' | 'status';
  lookup?: string;
  prefix?: string;
};

export type ResourceConfig = {
  key: string;
  endpoint: string;
  title: string;
  eyebrow: string;
  description: string;
  singular: string;
  idKey?: string;
  keyFields?: string[];
  fields: FieldConfig[];
  columns: ColumnConfig[];
  sources?: SourceConfig[];
};

const customers: SourceConfig = { key: 'customers', endpoint: '/customers', idKey: 'customer_id', labelKey: 'name' };
const designers: SourceConfig = { key: 'designers', endpoint: '/designers', idKey: 'designer_id', labelKey: 'name' };
const designs: SourceConfig = { key: 'designs', endpoint: '/designs', idKey: 'design_id', labelKey: 'style_name' };
const orders: SourceConfig = { key: 'orders', endpoint: '/orders', idKey: 'order_id', labelKey: 'order_id', prefix: 'ORD-' };
const tailors: SourceConfig = { key: 'tailors', endpoint: '/tailors', idKey: 'tailor_id', labelKey: 'name' };
const suppliers: SourceConfig = { key: 'suppliers', endpoint: '/suppliers', idKey: 'supplier_id', labelKey: 'name' };
const fabrics: SourceConfig = { key: 'fabrics', endpoint: '/fabrics', idKey: 'fabric_id', labelKey: 'name' };
const garments: SourceConfig = { key: 'garments', endpoint: '/garments', idKey: 'garment_id', labelKey: 'garment_id', prefix: 'GAR-' };

export const resources: Record<string, ResourceConfig> = {
  customers: {
    key: 'customers', endpoint: '/customers', idKey: 'customer_id', title: 'Customers', singular: 'customer', eyebrow: 'Relationships',
    description: 'Manage client profiles, contact information and delivery addresses. Changes are saved to MongoDB.',
    fields: [
      { key: 'name', label: 'Full name', required: true },
      { key: 'contact_info', label: 'Contact information' },
      { key: 'address', label: 'Address' },
    ],
    columns: [{ key: 'customer_id', label: 'Customer ID', prefix: 'CU-' }, { key: 'name', label: 'Customer' }, { key: 'contact_info', label: 'Contact' }, { key: 'address', label: 'Address' }],
  },
  measurements: {
    key: 'measurements', endpoint: '/measurements', idKey: 'measurement_id', title: 'Measurements', singular: 'measurement', eyebrow: 'Fit profiles',
    description: 'Keep individual measurement records for repeat orders and accurate fittings. Measurements are stored in inches.',
    sources: [customers],
    fields: [
      { key: 'customer_id', label: 'Customer', type: 'select', source: 'customers', required: true },
      { key: 'chest', label: 'Chest (in)', type: 'number', step: '0.1' }, { key: 'waist', label: 'Waist (in)', type: 'number', step: '0.1' },
      { key: 'hip', label: 'Hip (in)', type: 'number', step: '0.1' }, { key: 'shoulder', label: 'Shoulder (in)', type: 'number', step: '0.1' },
      { key: 'length', label: 'Length (in)', type: 'number', step: '0.1' }, { key: 'taken_date', label: 'Measurement date', type: 'date' },
    ],
    columns: [{ key: 'measurement_id', label: 'Record', prefix: 'MEA-' }, { key: 'customer_id', label: 'Customer', lookup: 'customers' }, { key: 'chest', label: 'Chest' }, { key: 'waist', label: 'Waist' }, { key: 'hip', label: 'Hip' }, { key: 'shoulder', label: 'Shoulder' }, { key: 'length', label: 'Length' }, { key: 'taken_date', label: 'Taken on', format: 'date' }],
  },
  designers: {
    key: 'designers', endpoint: '/designers', idKey: 'designer_id', title: 'Designers', singular: 'designer', eyebrow: 'Creative studio',
    description: 'Maintain your design team, specialties and contact details.',
    fields: [{ key: 'name', label: 'Full name', required: true }, { key: 'specialty', label: 'Specialty' }, { key: 'contact_info', label: 'Contact information' }],
    columns: [{ key: 'designer_id', label: 'Designer ID', prefix: 'DES-' }, { key: 'name', label: 'Designer' }, { key: 'specialty', label: 'Specialty' }, { key: 'contact_info', label: 'Contact' }],
  },
  designs: {
    key: 'designs', endpoint: '/designs', idKey: 'design_id', title: 'Designs', singular: 'design', eyebrow: 'Creative studio',
    description: 'Link a style and sketch notes to its customer and designer before creating an order.',
    sources: [customers, designers],
    fields: [{ key: 'style_name', label: 'Style name', required: true }, { key: 'customer_id', label: 'Customer', type: 'select', source: 'customers', required: true },
      { key: 'designer_id', label: 'Designer', type: 'select', source: 'designers', required: true }, { key: 'created_date', label: 'Created date', type: 'date' },
      { key: 'sketch_details', label: 'Sketch / design notes', type: 'textarea' }],
    columns: [{ key: 'design_id', label: 'Design ID', prefix: 'DSN-' }, { key: 'style_name', label: 'Style' }, { key: 'customer_id', label: 'Customer', lookup: 'customers' }, { key: 'designer_id', label: 'Designer', lookup: 'designers' }, { key: 'created_date', label: 'Created', format: 'date' }, { key: 'sketch_details', label: 'Sketch notes' }],
  },
  orders: {
    key: 'orders', endpoint: '/orders', idKey: 'order_id', title: 'Orders', singular: 'order', eyebrow: 'Commerce',
    description: 'Create and maintain customer orders, connect them to a design, and track their current stage.',
    sources: [customers, designs],
    fields: [{ key: 'customer_id', label: 'Customer', type: 'select', source: 'customers', required: true }, { key: 'design_id', label: 'Design', type: 'select', source: 'designs', required: true },
      { key: 'order_date', label: 'Order date', type: 'date' }, { key: 'status', label: 'Order status', type: 'select', options: ['Pending', 'Processing', 'Trial', 'Completed', 'Delivered'], required: true }],
    columns: [{ key: 'order_id', label: 'Order', prefix: 'ORD-' }, { key: 'customer_id', label: 'Customer', lookup: 'customers' }, { key: 'design_id', label: 'Design', lookup: 'designs' }, { key: 'order_date', label: 'Placed', format: 'date' }, { key: 'status', label: 'Status', format: 'status' }],
  },
  tailors: {
    key: 'tailors', endpoint: '/tailors', idKey: 'tailor_id', title: 'Tailors', singular: 'tailor', eyebrow: 'Workshop team',
    description: 'Manage tailoring staff and assign skill levels for garment production.',
    fields: [{ key: 'name', label: 'Full name', required: true }, { key: 'skill_level', label: 'Skill level', type: 'select', options: ['Apprentice', 'Junior', 'Senior', 'Master'] }, { key: 'contact_info', label: 'Contact information' }],
    columns: [{ key: 'tailor_id', label: 'Tailor ID', prefix: 'TLR-' }, { key: 'name', label: 'Tailor' }, { key: 'skill_level', label: 'Skill level' }, { key: 'contact_info', label: 'Contact' }],
  },
  suppliers: {
    key: 'suppliers', endpoint: '/suppliers', idKey: 'supplier_id', title: 'Suppliers', singular: 'supplier', eyebrow: 'Supply network',
    description: 'Maintain supplier contact details and the partners behind your material inventory.',
    fields: [{ key: 'name', label: 'Supplier name', required: true }, { key: 'contact_info', label: 'Contact information' }],
    columns: [{ key: 'supplier_id', label: 'Supplier ID', prefix: 'SUP-' }, { key: 'name', label: 'Supplier' }, { key: 'contact_info', label: 'Contact' }],
  },
  fabrics: {
    key: 'fabrics', endpoint: '/fabrics', idKey: 'fabric_id', title: 'Fabrics', singular: 'fabric', eyebrow: 'Material library',
    description: 'Manage fabric types, colours, supplier links and cost per meter.', sources: [suppliers],
    fields: [{ key: 'name', label: 'Fabric name', required: true }, { key: 'supplier_id', label: 'Supplier', type: 'select', source: 'suppliers', required: true },
      { key: 'type', label: 'Fabric type' }, { key: 'color', label: 'Colour' }, { key: 'cost_per_meter', label: 'Cost per meter (₹)', type: 'number', step: '0.01' }],
    columns: [{ key: 'fabric_id', label: 'Fabric ID', prefix: 'FAB-' }, { key: 'name', label: 'Fabric' }, { key: 'type', label: 'Type' }, { key: 'color', label: 'Colour' }, { key: 'supplier_id', label: 'Supplier', lookup: 'suppliers' }, { key: 'cost_per_meter', label: '₹ / meter', format: 'money' }],
  },
  garments: {
    key: 'garments', endpoint: '/garments', idKey: 'garment_id', title: 'Garments & Production', singular: 'garment', eyebrow: 'Workshop',
    description: 'Manage garment production records, tailor assignments and stitching milestones.', sources: [orders, tailors],
    fields: [{ key: 'order_id', label: 'Order', type: 'select', source: 'orders', required: true }, { key: 'tailor_id', label: 'Assigned tailor', type: 'select', source: 'tailors', required: true },
      { key: 'stitching_start', label: 'Stitching start', type: 'date' }, { key: 'stitching_end', label: 'Stitching end', type: 'date' },
      { key: 'stitching_status', label: 'Production status', type: 'select', options: ['Pending', 'Stitching', 'Trial', 'Completed'], required: true }],
    columns: [{ key: 'garment_id', label: 'Garment', prefix: 'GAR-' }, { key: 'order_id', label: 'Order', lookup: 'orders' }, { key: 'tailor_id', label: 'Tailor', lookup: 'tailors' }, { key: 'stitching_start', label: 'Started', format: 'date' }, { key: 'stitching_end', label: 'Finished', format: 'date' }, { key: 'stitching_status', label: 'Status', format: 'status' }],
  },
  garmentFabrics: {
    key: 'garmentFabrics', endpoint: '/garment-fabrics', title: 'Garment–Fabric Usage', singular: 'fabric usage link', eyebrow: 'Material allocation', idKey: 'garment_id', keyFields: ['garment_id', 'fabric_id'],
    description: 'Connect fabrics to each garment and record the quantity consumed. Together these rows power fabric usage reporting.', sources: [garments, fabrics],
    fields: [{ key: 'garment_id', label: 'Garment', type: 'select', source: 'garments', required: true }, { key: 'fabric_id', label: 'Fabric', type: 'select', source: 'fabrics', required: true }, { key: 'quantity_used', label: 'Quantity used (meters)', type: 'number', step: '0.01' }],
    columns: [{ key: 'garment_id', label: 'Garment', lookup: 'garments' }, { key: 'fabric_id', label: 'Fabric', lookup: 'fabrics' }, { key: 'quantity_used', label: 'Quantity used (m)' }],
  },
  trials: {
    key: 'trials', endpoint: '/trials', idKey: 'trial_id', title: 'Trial Sessions', singular: 'trial session', eyebrow: 'Fittings',
    description: 'Schedule fittings, record feedback and update fitting outcomes before delivery.', sources: [orders],
    fields: [{ key: 'order_id', label: 'Order', type: 'select', source: 'orders', required: true }, { key: 'scheduled_date', label: 'Scheduled date & time', type: 'datetime', required: true },
      { key: 'fitting_status', label: 'Fitting status', type: 'select', options: ['Scheduled', 'In Progress', 'Adjustment Required', 'Approved', 'Completed'], required: true },
      { key: 'feedback', label: 'Feedback / alteration notes', type: 'textarea' }],
    columns: [{ key: 'trial_id', label: 'Trial', prefix: 'TRY-' }, { key: 'order_id', label: 'Order', lookup: 'orders' }, { key: 'scheduled_date', label: 'Scheduled', format: 'datetime' }, { key: 'fitting_status', label: 'Fitting status', format: 'status' }, { key: 'feedback', label: 'Feedback' }],
  },
  deliveries: {
    key: 'deliveries', endpoint: '/deliveries', idKey: 'delivery_id', title: 'Deliveries', singular: 'delivery', eyebrow: 'Fulfilment',
    description: 'Schedule and track the final handoff of a completed order. Each order can have one delivery record.', sources: [orders],
    fields: [{ key: 'order_id', label: 'Order', type: 'select', source: 'orders', required: true }, { key: 'delivery_date', label: 'Delivery date', type: 'date' },
      { key: 'address', label: 'Delivery address', type: 'textarea' }, { key: 'status', label: 'Delivery status', type: 'select', options: ['Pending', 'Ready', 'Dispatched', 'Delivered', 'Cancelled'], required: true }],
    columns: [{ key: 'delivery_id', label: 'Delivery', prefix: 'DEL-' }, { key: 'order_id', label: 'Order', lookup: 'orders' }, { key: 'delivery_date', label: 'Delivery date', format: 'date' }, { key: 'address', label: 'Address' }, { key: 'status', label: 'Status', format: 'status' }],
  },
};
