from __future__ import annotations

import os
import re
import time
from datetime import date, datetime, timedelta
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from pymongo import ASCENDING, DESCENDING, MongoClient, ReturnDocument
from pymongo.collection import Collection
from pymongo.errors import DuplicateKeyError, PyMongoError, ServerSelectionTimeoutError

APP_NAME = os.getenv("APP_NAME", "TailorPro Atelier")
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27018")
MONGODB_DB = os.getenv("MONGODB_DB", "tailorpro")
MONGO_HOST_PORT = os.getenv("MONGO_HOST_PORT", "27018")

client = MongoClient(
    MONGODB_URI,
    serverSelectionTimeoutMS=2500,
    connectTimeoutMS=2500,
    socketTimeoutMS=5000,
    appname="TailorProAtelier",
)
db = client[MONGODB_DB]

app = FastAPI(
    title="TailorPro Atelier API",
    description=(
        "A MongoDB-backed custom garment studio platform. Manages customers, body measurements, "
        "designs, orders, garment production, textile inventory, fittings and deliveries."
    ),
    version="3.0.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# The 12 collections map one-to-one to the entities in the supplied ERD.
COLLECTIONS: dict[str, dict[str, str]] = {
    "customers": {"id": "customer_id", "label": "Customers", "table": "Customer", "endpoint": "/customers"},
    "measurements": {"id": "measurement_id", "label": "Measurements", "table": "Measurement", "endpoint": "/measurements"},
    "designers": {"id": "designer_id", "label": "Designers", "table": "Designer", "endpoint": "/designers"},
    "designs": {"id": "design_id", "label": "Designs", "table": "Design", "endpoint": "/designs"},
    "orders": {"id": "order_id", "label": "Orders", "table": "Orders", "endpoint": "/orders"},
    "tailors": {"id": "tailor_id", "label": "Tailors", "table": "Tailor", "endpoint": "/tailors"},
    "suppliers": {"id": "supplier_id", "label": "Suppliers", "table": "Supplier", "endpoint": "/suppliers"},
    "fabrics": {"id": "fabric_id", "label": "Fabrics", "table": "Fabric", "endpoint": "/fabrics"},
    "garments": {"id": "garment_id", "label": "Garments & Production", "table": "Garment", "endpoint": "/garments"},
    "garment_fabrics": {"id": "garment_id", "label": "Garment–Fabric Usage", "table": "Garment_Fabric", "endpoint": "/garment-fabrics"},
    "trial_sessions": {"id": "trial_id", "label": "Trial Sessions", "table": "Trial_Session", "endpoint": "/trials"},
    "deliveries": {"id": "delivery_id", "label": "Deliveries", "table": "Delivery", "endpoint": "/deliveries"},
}


def coll(name: str) -> Collection:
    return db[name]


def serialize(doc: dict[str, Any] | None) -> dict[str, Any] | None:
    """Remove Mongo's internal ObjectId from API responses; public ERD IDs remain visible."""
    if doc is None:
        return None
    return {key: value for key, value in doc.items() if key != "_id"}


def serialize_many(docs) -> list[dict[str, Any]]:
    return [serialize(doc) for doc in docs]


def next_id(collection_name: str, id_field: str) -> int:
    counter = db.counters.find_one_and_update(
        {"_id": collection_name},
        {"$inc": {"seq": 1}},
        upsert=True,
        return_document=ReturnDocument.AFTER,
    )
    return int(counter["seq"])


def ensure_indexes() -> None:
    for name, meta in COLLECTIONS.items():
        if name == "garment_fabrics":
            coll(name).create_index([("garment_id", ASCENDING), ("fabric_id", ASCENDING)], unique=True)
        else:
            coll(name).create_index([(meta["id"], ASCENDING)], unique=True)
    coll("deliveries").create_index("order_id", unique=True)
    coll("customers").create_index([("name", ASCENDING)])
    coll("orders").create_index([("status", ASCENDING), ("order_date", DESCENDING)])
    coll("trial_sessions").create_index([("scheduled_date", ASCENDING)])
    coll("garments").create_index([("stitching_status", ASCENDING)])
    coll("fabrics").create_index([("supplier_id", ASCENDING)])


# ------------------------------ Validation schemas ------------------------------
class CustomerCreate(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    contact_info: str | None = Field(default=None, max_length=255)
    address: str | None = Field(default=None, max_length=255)


class CustomerOut(CustomerCreate):
    customer_id: int


class MeasurementCreate(BaseModel):
    customer_id: int = Field(gt=0)
    chest: float | None = Field(default=None, ge=0, le=999)
    waist: float | None = Field(default=None, ge=0, le=999)
    hip: float | None = Field(default=None, ge=0, le=999)
    shoulder: float | None = Field(default=None, ge=0, le=999)
    length: float | None = Field(default=None, ge=0, le=999)
    taken_date: date | None = None


class MeasurementOut(MeasurementCreate):
    measurement_id: int


class DesignerCreate(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    specialty: str | None = Field(default=None, max_length=100)
    contact_info: str | None = Field(default=None, max_length=255)


class DesignerOut(DesignerCreate):
    designer_id: int


class TailorCreate(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    skill_level: str | None = Field(default=None, max_length=50)
    contact_info: str | None = Field(default=None, max_length=255)


class TailorOut(TailorCreate):
    tailor_id: int


class SupplierCreate(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    contact_info: str | None = Field(default=None, max_length=255)


class SupplierOut(SupplierCreate):
    supplier_id: int


class DesignCreate(BaseModel):
    designer_id: int = Field(gt=0)
    customer_id: int = Field(gt=0)
    style_name: str = Field(min_length=1, max_length=150)
    sketch_details: str | None = None
    created_date: date | None = None


class DesignOut(DesignCreate):
    design_id: int


class OrderCreate(BaseModel):
    customer_id: int = Field(gt=0)
    design_id: int = Field(gt=0)
    order_date: date | None = None
    status: str = Field(default="Pending", min_length=1, max_length=30)


class OrderOut(OrderCreate):
    order_id: int


class FabricCreate(BaseModel):
    supplier_id: int = Field(gt=0)
    name: str = Field(min_length=1, max_length=150)
    type: str | None = Field(default=None, max_length=100)
    color: str | None = Field(default=None, max_length=50)
    cost_per_meter: float | None = Field(default=None, ge=0, le=999999)


class FabricOut(FabricCreate):
    fabric_id: int


class GarmentCreate(BaseModel):
    order_id: int = Field(gt=0)
    tailor_id: int = Field(gt=0)
    stitching_start: date | None = None
    stitching_end: date | None = None
    stitching_status: str = Field(default="Pending", min_length=1, max_length=30)


class GarmentOut(GarmentCreate):
    garment_id: int


class GarmentFabricCreate(BaseModel):
    garment_id: int = Field(gt=0)
    fabric_id: int = Field(gt=0)
    quantity_used: float | None = Field(default=None, ge=0, le=999999)


class GarmentFabricOut(GarmentFabricCreate):
    pass


class TrialCreate(BaseModel):
    order_id: int = Field(gt=0)
    scheduled_date: datetime
    feedback: str | None = None
    fitting_status: str = Field(default="Scheduled", min_length=1, max_length=40)


class TrialOut(TrialCreate):
    trial_id: int


class DeliveryCreate(BaseModel):
    order_id: int = Field(gt=0)
    delivery_date: date | None = None
    address: str | None = Field(default=None, max_length=255)
    status: str = Field(default="Pending", min_length=1, max_length=30)


class DeliveryOut(DeliveryCreate):
    delivery_id: int


# ------------------------------ Data helpers ------------------------------
REFERENCES: dict[str, list[tuple[str, str, str]]] = {
    "measurements": [("customer_id", "customers", "customer_id")],
    "designs": [("designer_id", "designers", "designer_id"), ("customer_id", "customers", "customer_id")],
    "orders": [("customer_id", "customers", "customer_id"), ("design_id", "designs", "design_id")],
    "fabrics": [("supplier_id", "suppliers", "supplier_id")],
    "garments": [("order_id", "orders", "order_id"), ("tailor_id", "tailors", "tailor_id")],
    "garment_fabrics": [("garment_id", "garments", "garment_id"), ("fabric_id", "fabrics", "fabric_id")],
    "trial_sessions": [("order_id", "orders", "order_id")],
    "deliveries": [("order_id", "orders", "order_id")],
}

DELETE_DEPENDENTS: dict[str, list[tuple[str, str]]] = {
    "customers": [("measurements", "customer_id"), ("designs", "customer_id"), ("orders", "customer_id")],
    "designers": [("designs", "designer_id")],
    "tailors": [("garments", "tailor_id")],
    "suppliers": [("fabrics", "supplier_id")],
    "designs": [("orders", "design_id")],
    "orders": [("garments", "order_id"), ("trial_sessions", "order_id"), ("deliveries", "order_id")],
    "garments": [("garment_fabrics", "garment_id")],
    "fabrics": [("garment_fabrics", "fabric_id")],
}


def require_ref(collection_name: str, id_field: str, record_id: int, label: str | None = None) -> None:
    if coll(collection_name).find_one({id_field: record_id}, {"_id": 1}) is None:
        raise HTTPException(status_code=422, detail=f"{label or collection_name.title()} #{record_id} does not exist")


def validate_references(name: str, values: dict[str, Any]) -> None:
    for field, target_collection, target_id_field in REFERENCES.get(name, []):
        value = values.get(field)
        if value is not None:
            require_ref(target_collection, target_id_field, int(value), target_collection.rstrip("s").replace("_", " ").title())
    if name == "orders":
        design = coll("designs").find_one({"design_id": int(values["design_id"])}, {"_id": 0, "customer_id": 1})
        if design and int(design.get("customer_id", 0)) != int(values["customer_id"]):
            raise HTTPException(status_code=422, detail="The selected design belongs to a different customer")


def create_record(name: str, payload: BaseModel, id_field: str) -> dict[str, Any]:
    values = payload.model_dump(mode="json")
    for field in {"measurements": "taken_date", "designs": "created_date", "orders": "order_date"}.get(name, "").split():
        if not values.get(field):
            values[field] = date.today().isoformat()
    validate_references(name, values)
    record_id = next_id(name, id_field)
    values[id_field] = record_id
    try:
        coll(name).insert_one(values)
    except DuplicateKeyError as exc:
        raise HTTPException(status_code=409, detail="A record with this identifier already exists") from exc
    return values


def update_record(name: str, record_id: int, payload: BaseModel, id_field: str, label: str) -> dict[str, Any]:
    existing = coll(name).find_one({id_field: record_id})
    if not existing:
        raise HTTPException(status_code=404, detail=f"{label} not found")
    values = payload.model_dump(mode="json")
    for field in {"measurements": "taken_date", "designs": "created_date", "orders": "order_date"}.get(name, "").split():
        if not values.get(field):
            values[field] = date.today().isoformat()
    validate_references(name, values)
    values[id_field] = record_id
    try:
        coll(name).update_one({id_field: record_id}, {"$set": values})
    except DuplicateKeyError as exc:
        raise HTTPException(status_code=409, detail="This change conflicts with a unique database constraint") from exc
    return values


def delete_record(name: str, record_id: int, id_field: str, label: str) -> dict[str, Any]:
    existing = coll(name).find_one({id_field: record_id}, {"_id": 1})
    if not existing:
        raise HTTPException(status_code=404, detail=f"{label} not found")
    blockers = []
    for child_name, foreign_key in DELETE_DEPENDENTS.get(name, []):
        count = coll(child_name).count_documents({foreign_key: record_id})
        if count:
            blockers.append(f"{COLLECTIONS[child_name]['label']} ({count})")
    if name == "orders":
        # Keep a clear referential rule while the order is still referenced in fabric-independent history.
        pass
    if blockers:
        raise HTTPException(status_code=409, detail=f"Cannot delete {label.lower()} while linked records exist: {', '.join(blockers)}. Remove or reassign those records first.")
    coll(name).delete_one({id_field: record_id})
    return {"deleted": True, id_field: record_id}


def list_records(name: str, sort_field: str | None = None, direction: int = ASCENDING, filter_query: dict[str, Any] | None = None):
    cursor = coll(name).find(filter_query or {}, {"_id": 0})
    if sort_field:
        cursor = cursor.sort(sort_field, direction)
    return list(cursor)


def count(name: str, query: dict[str, Any] | None = None) -> int:
    return int(coll(name).count_documents(query or {}))


# ------------------------------ Demo records ------------------------------
def seed_demo() -> bool:
    if count("customers") > 0:
        # Repair sequences if the DB was imported manually or partially seeded.
        for name, meta in COLLECTIONS.items():
            max_doc = coll(name).find_one(sort=[(meta["id"], DESCENDING)], projection={meta["id"]: 1})
            if max_doc and isinstance(max_doc.get(meta["id"]), int):
                db.counters.update_one({"_id": name}, {"$max": {"seq": max_doc[meta["id"]]}}, upsert=True)
        return False

    today = date.today()
    now = datetime.now().replace(second=0, microsecond=0)
    customers = [
        {"customer_id": i + 1, "name": name, "contact_info": phone, "address": address}
        for i, (name, phone, address) in enumerate([
            ("Aarav Sharma", "+91 98765 12001", "Koregaon Park, Pune"),
            ("Ananya Mehta", "+91 98765 12002", "Baner, Pune"),
            ("Rohan Kulkarni", "+91 98765 12003", "Kothrud, Pune"),
            ("Kiara Desai", "+91 98765 12004", "Viman Nagar, Pune"),
            ("Vivaan Shah", "+91 98765 12005", "Aundh, Pune"),
            ("Ira Patil", "+91 98765 12006", "Magarpatta, Pune"),
            ("Reyansh Kapoor", "+91 98765 12007", "Pimple Saudagar, Pune"),
            ("Sana Merchant", "+91 98765 12008", "Kalyani Nagar, Pune"),
            ("Aditi Joshi", "+91 98765 12009", "Wakad, Pune"),
            ("Kabir Nair", "+91 98765 12010", "Shivajinagar, Pune"),
        ])
    ]
    designers = [
        {"designer_id": i + 1, "name": name, "specialty": specialty, "contact_info": f"{name.lower().replace(' ', '.')}@tailorpro.demo"}
        for i, (name, specialty) in enumerate([
            ("Mira Khanna", "Contemporary ethnic"), ("Ishaan Rao", "Formal tailoring"),
            ("Naina Kapoor", "Bridal & occasion"), ("Dev Malhotra", "Minimalist couture"),
        ])
    ]
    tailors = [
        {"tailor_id": i + 1, "name": name, "skill_level": level, "contact_info": f"+91 98000 100{i+1:02d}"}
        for i, (name, level) in enumerate([
            ("Rajesh Pawar", "Master"), ("Sameer Shaikh", "Senior"), ("Kavita Jadhav", "Master"),
            ("Manoj Shinde", "Senior"), ("Arjun More", "Junior"), ("Farhan Khan", "Senior"),
        ])
    ]
    suppliers = [
        {"supplier_id": i + 1, "name": name, "contact_info": contact}
        for i, (name, contact) in enumerate([
            ("Regal Textiles", "+91 20 2500 1101"), ("The Fabric House", "+91 20 2500 1102"),
            ("Silk Route Supply", "+91 20 2500 1103"), ("Cotton & Co.", "+91 20 2500 1104"),
        ])
    ]
    designs = [
        {"design_id": i + 1, "designer_id": (i % len(designers)) + 1, "customer_id": (i % len(customers)) + 1,
         "style_name": style, "sketch_details": details, "created_date": (today - timedelta(days=(i * 3 + 2))).isoformat()}
        for i, (style, details) in enumerate([
            ("Ivory Wedding Sherwani", "Structured shoulders, antique-gold buttons, tapered hem."),
            ("Midnight Slim Suit", "Single-breasted, peak lapel, half-canvas construction."),
            ("Rose Silk Anarkali", "Layered silk, hand-finished neckline, concealed fastening."),
            ("Everyday Linen Shirt", "Relaxed fit with French seams and mother-of-pearl buttons."),
            ("Emerald Occasion Jacket", "Jewel tone, minimal embroidery, contrast lining."),
            ("Classic Bandhgala", "Clean collar line, hidden placket, tailored waist."),
            ("Champagne Reception Gown", "Soft drape, fitted bodice and subtle beadwork."),
            ("Charcoal Three-piece Suit", "Waistcoat, slim trousers and satin pocket square."),
            ("Indigo Kurta Set", "Textured cotton, side slits and matching trousers."),
            ("Bespoke Blazer", "Unstructured shoulder and horn buttons."),
            ("Printed Festive Co-ord", "Matching top and bottom with clean piping."),
            ("Classic Cotton Trousers", "Mid-rise straight fit with reinforced pockets."),
        ])
    ]
    statuses = ["Pending", "Processing", "Processing", "Trial", "Completed", "Delivered", "Processing", "Trial", "Delivered", "Pending", "Completed", "Processing", "Delivered", "Trial", "Pending", "Completed"]
    orders = [
        {"order_id": i + 1, "customer_id": designs[i % len(designs)]["customer_id"], "design_id": designs[i % len(designs)]["design_id"],
         "order_date": (today - timedelta(days=(i * 2 + 1))).isoformat(), "status": statuses[i]}
        for i in range(16)
    ]
    fabrics = [
        {"fabric_id": i + 1, "supplier_id": (i % len(suppliers)) + 1, "name": name, "type": kind, "color": color, "cost_per_meter": cost}
        for i, (name, kind, color, cost) in enumerate([
            ("Italian Wool", "Wool", "Charcoal", 1850.0), ("Pure Mulberry Silk", "Silk", "Ivory", 2400.0),
            ("Premium Cotton", "Cotton", "Optic White", 460.0), ("Linen Blend", "Linen", "Sand", 780.0),
            ("Raw Silk", "Silk", "Emerald", 1650.0), ("Velvet Finish", "Velvet", "Midnight", 1250.0),
            ("Banarasi Brocade", "Brocade", "Antique Gold", 3100.0), ("Tencel Twill", "Tencel", "Stone", 890.0),
            ("Chiffon Drape", "Chiffon", "Rose", 520.0), ("Tweed Texture", "Tweed", "Olive", 1450.0),
            ("Organic Poplin", "Cotton", "Sky Blue", 510.0), ("Satin Lining", "Satin", "Burgundy", 390.0),
        ])
    ]
    garment_statuses = ["Stitching", "Pending", "Trial", "Completed", "Stitching", "Trial", "Pending", "Completed", "Stitching", "Pending", "Completed", "Trial", "Stitching", "Pending"]
    garments = [
        {"garment_id": i + 1, "order_id": i + 1, "tailor_id": (i % len(tailors)) + 1,
         "stitching_start": (today - timedelta(days=10 - (i % 7))).isoformat() if garment_statuses[i] != "Pending" else None,
         "stitching_end": (today - timedelta(days=(i % 3 + 1))).isoformat() if garment_statuses[i] == "Completed" else None,
         "stitching_status": garment_statuses[i]}
        for i in range(14)
    ]
    measurements = [
        {"measurement_id": i + 1, "customer_id": (i % len(customers)) + 1, "chest": 36.0 + (i % 6) * 1.5,
         "waist": 28.0 + (i % 7) * 1.5, "hip": 35.0 + (i % 5) * 1.4, "shoulder": 15.5 + (i % 4) * 0.5,
         "length": 26.0 + (i % 5) * 0.7, "taken_date": (today - timedelta(days=i * 4 + 1)).isoformat()}
        for i in range(12)
    ]
    links = [
        {"garment_id": garment["garment_id"], "fabric_id": ((garment["garment_id"] * 2 - 1) % len(fabrics)) + 1,
         "quantity_used": round(1.2 + (garment["garment_id"] % 5) * 0.35, 2)}
        for garment in garments
    ]
    links += [
        {"garment_id": garment["garment_id"], "fabric_id": (garment["garment_id"] % len(fabrics)) + 1,
         "quantity_used": round(0.5 + (garment["garment_id"] % 3) * 0.2, 2)}
        for garment in garments if garment["garment_id"] % 3 == 0
    ]
    trials = [
        {"trial_id": i + 1, "order_id": order_id, "scheduled_date": (now + timedelta(days=(i - 3), hours=10 + i % 5)).isoformat(),
         "feedback": feedback, "fitting_status": status}
        for i, (order_id, feedback, status) in enumerate([
            (1, "Shoulder feels slightly tight; let out by 0.5 inch.", "Adjustment Required"),
            (3, "Length approved. Please finish the sleeve buttons.", "Approved"),
            (4, "First fitting scheduled with the customer.", "Scheduled"),
            (6, "Waist fit approved; proceed to finishing.", "Completed"),
            (8, "Pinch at left armhole; check movement.", "Adjustment Required"),
            (10, "Customer requested a cleaner hemline.", "In Progress"),
            (12, "Fit looks good; awaiting final confirmation.", "Approved"),
            (15, "Initial measurement check.", "Scheduled"),
        ])
    ]
    deliveries = [
        {"delivery_id": i + 1, "order_id": i + 1, "delivery_date": (today + timedelta(days=i - 5)).isoformat(),
         "address": customers[i % len(customers)]["address"],
         "status": ("Delivered" if i < 3 else "Dispatched" if i < 6 else "Ready" if i < 9 else "Pending")}
        for i in range(12)
    ]
    docs_by_collection = {
        "customers": customers, "designers": designers, "tailors": tailors, "suppliers": suppliers,
        "measurements": measurements, "designs": designs, "orders": orders, "fabrics": fabrics,
        "garments": garments, "garment_fabrics": links, "trial_sessions": trials, "deliveries": deliveries,
    }
    for name, docs in docs_by_collection.items():
        if docs:
            coll(name).insert_many(docs)
        id_key = COLLECTIONS[name]["id"]
        max_id = max((int(item.get(id_key, 0)) for item in docs), default=0)
        db.counters.update_one({"_id": name}, {"$set": {"seq": max_id}}, upsert=True)
    return True


@app.on_event("startup")
def startup() -> None:
    last_error: Exception | None = None
    for attempt in range(1, 41):
        try:
            client.admin.command("ping")
            ensure_indexes()
            seed_demo()
            return
        except (PyMongoError, ServerSelectionTimeoutError) as exc:
            last_error = exc
            if attempt == 40:
                raise RuntimeError(f"MongoDB did not become ready: {exc}") from exc
            time.sleep(1.5)
    if last_error:
        raise RuntimeError(f"MongoDB did not become ready: {last_error}")


@app.get("/health")
def health() -> dict[str, Any]:
    try:
        client.admin.command("ping")
        return {
            "status": "ok", "database": "connected", "database_engine": "MongoDB", "database_name": MONGODB_DB,
            "service": APP_NAME, "counts": {"customers": count("customers"), "designs": count("designs"), "orders": count("orders")},
        }
    except PyMongoError as exc:
        raise HTTPException(status_code=503, detail=f"MongoDB is unavailable: {exc.__class__.__name__}") from exc


@app.get("/api/dashboard")
def dashboard() -> dict[str, Any]:
    order_status = list(coll("orders").aggregate([{"$group": {"_id": "$status", "count": {"$sum": 1}}}, {"$sort": {"_id": 1}}]))
    status_items = [{"status": item.get("_id") or "Unspecified", "count": int(item.get("count", 0))} for item in order_status]
    active_garments = count("garments", {"stitching_status": {"$in": ["Pending", "Stitching", "Trial"]}})
    adjustments = count("trial_sessions", {"fitting_status": "Adjustment Required"})
    ready_deliveries = count("deliveries", {"status": {"$in": ["Ready", "Dispatched"]}})
    material_summary = list(coll("garment_fabrics").aggregate([
        {"$lookup": {"from": "fabrics", "localField": "fabric_id", "foreignField": "fabric_id", "as": "fabric_doc"}},
        {"$unwind": {"path": "$fabric_doc", "preserveNullAndEmptyArrays": True}},
        {"$group": {"_id": None, "cost": {"$sum": {"$multiply": [{"$ifNull": ["$quantity_used", 0]}, {"$ifNull": ["$fabric_doc.cost_per_meter", 0]}]}}}},
    ]))
    return {
        "customers": count("customers"), "orders": count("orders"), "garments": active_garments,
        "trials": count("trial_sessions", {"fitting_status": {"$in": ["Scheduled", "In Progress", "Adjustment Required"]}}),
        "deliveries": count("deliveries", {"status": {"$ne": "Delivered"}}), "fabrics": count("fabrics"),
        "estimated_material_cost": round(float(material_summary[0]["cost"]) if material_summary else 0, 2),
        "adjustments_needed": adjustments, "ready_deliveries": ready_deliveries, "order_status": status_items,
    }


# ------------------------------ CRUD API ------------------------------
@app.get("/api/customers", response_model=list[CustomerOut])
def list_customers(search: str | None = Query(default=None, max_length=120)):
    query: dict[str, Any] = {}
    if search and search.strip():
        escaped = re.escape(search.strip())
        query = {"$or": [{"name": {"$regex": escaped, "$options": "i"}}, {"contact_info": {"$regex": escaped, "$options": "i"}}, {"address": {"$regex": escaped, "$options": "i"}}]}
    return list_records("customers", "name", ASCENDING, query)

@app.get("/api/customers/{customer_id}", response_model=CustomerOut)
def get_customer(customer_id: int):
    doc = coll("customers").find_one({"customer_id": customer_id}, {"_id": 0})
    if not doc: raise HTTPException(404, detail="Customer not found")
    return doc

@app.post("/api/customers", response_model=CustomerOut, status_code=201)
def create_customer(payload: CustomerCreate): return create_record("customers", payload, "customer_id")

@app.put("/api/customers/{customer_id}", response_model=CustomerOut)
def put_customer(customer_id: int, payload: CustomerCreate): return update_record("customers", customer_id, payload, "customer_id", "Customer")

@app.delete("/api/customers/{customer_id}")
def remove_customer(customer_id: int): return delete_record("customers", customer_id, "customer_id", "Customer")


@app.get("/api/measurements", response_model=list[MeasurementOut])
def list_measurements(customer_id: int | None = None):
    q = {"customer_id": customer_id} if customer_id is not None else {}
    return list_records("measurements", "taken_date", DESCENDING, q)

@app.post("/api/measurements", response_model=MeasurementOut, status_code=201)
def create_measurement(payload: MeasurementCreate): return create_record("measurements", payload, "measurement_id")

@app.put("/api/measurements/{measurement_id}", response_model=MeasurementOut)
def put_measurement(measurement_id: int, payload: MeasurementCreate): return update_record("measurements", measurement_id, payload, "measurement_id", "Measurement")

@app.delete("/api/measurements/{measurement_id}")
def remove_measurement(measurement_id: int): return delete_record("measurements", measurement_id, "measurement_id", "Measurement")


@app.get("/api/designers", response_model=list[DesignerOut])
def list_designers(): return list_records("designers", "name", ASCENDING)

@app.post("/api/designers", response_model=DesignerOut, status_code=201)
def create_designer(payload: DesignerCreate): return create_record("designers", payload, "designer_id")

@app.put("/api/designers/{designer_id}", response_model=DesignerOut)
def put_designer(designer_id: int, payload: DesignerCreate): return update_record("designers", designer_id, payload, "designer_id", "Designer")

@app.delete("/api/designers/{designer_id}")
def remove_designer(designer_id: int): return delete_record("designers", designer_id, "designer_id", "Designer")


@app.get("/api/designs", response_model=list[DesignOut])
def list_designs(): return list_records("designs", "design_id", DESCENDING)

@app.post("/api/designs", response_model=DesignOut, status_code=201)
def create_design(payload: DesignCreate): return create_record("designs", payload, "design_id")

@app.put("/api/designs/{design_id}", response_model=DesignOut)
def put_design(design_id: int, payload: DesignCreate): return update_record("designs", design_id, payload, "design_id", "Design")

@app.delete("/api/designs/{design_id}")
def remove_design(design_id: int): return delete_record("designs", design_id, "design_id", "Design")


@app.get("/api/orders", response_model=list[OrderOut])
def list_orders(): return list_records("orders", "order_id", DESCENDING)

@app.post("/api/orders", response_model=OrderOut, status_code=201)
def create_order(payload: OrderCreate): return create_record("orders", payload, "order_id")

@app.put("/api/orders/{order_id}", response_model=OrderOut)
def put_order(order_id: int, payload: OrderCreate): return update_record("orders", order_id, payload, "order_id", "Order")

@app.patch("/api/orders/{order_id}/status", response_model=OrderOut)
def update_order_status(order_id: int, status: str = Query(min_length=1, max_length=30)):
    existing = coll("orders").find_one({"order_id": order_id}, {"_id": 0})
    if not existing: raise HTTPException(404, detail="Order not found")
    coll("orders").update_one({"order_id": order_id}, {"$set": {"status": status}})
    existing["status"] = status
    return existing

@app.delete("/api/orders/{order_id}")
def remove_order(order_id: int): return delete_record("orders", order_id, "order_id", "Order")


@app.get("/api/tailors", response_model=list[TailorOut])
def list_tailors(): return list_records("tailors", "name", ASCENDING)

@app.post("/api/tailors", response_model=TailorOut, status_code=201)
def create_tailor(payload: TailorCreate): return create_record("tailors", payload, "tailor_id")

@app.put("/api/tailors/{tailor_id}", response_model=TailorOut)
def put_tailor(tailor_id: int, payload: TailorCreate): return update_record("tailors", tailor_id, payload, "tailor_id", "Tailor")

@app.delete("/api/tailors/{tailor_id}")
def remove_tailor(tailor_id: int): return delete_record("tailors", tailor_id, "tailor_id", "Tailor")


@app.get("/api/suppliers", response_model=list[SupplierOut])
def list_suppliers(): return list_records("suppliers", "name", ASCENDING)

@app.post("/api/suppliers", response_model=SupplierOut, status_code=201)
def create_supplier(payload: SupplierCreate): return create_record("suppliers", payload, "supplier_id")

@app.put("/api/suppliers/{supplier_id}", response_model=SupplierOut)
def put_supplier(supplier_id: int, payload: SupplierCreate): return update_record("suppliers", supplier_id, payload, "supplier_id", "Supplier")

@app.delete("/api/suppliers/{supplier_id}")
def remove_supplier(supplier_id: int): return delete_record("suppliers", supplier_id, "supplier_id", "Supplier")


@app.get("/api/fabrics", response_model=list[FabricOut])
def list_fabrics(): return list_records("fabrics", "fabric_id", DESCENDING)

@app.post("/api/fabrics", response_model=FabricOut, status_code=201)
def create_fabric(payload: FabricCreate): return create_record("fabrics", payload, "fabric_id")

@app.put("/api/fabrics/{fabric_id}", response_model=FabricOut)
def put_fabric(fabric_id: int, payload: FabricCreate): return update_record("fabrics", fabric_id, payload, "fabric_id", "Fabric")

@app.delete("/api/fabrics/{fabric_id}")
def remove_fabric(fabric_id: int): return delete_record("fabrics", fabric_id, "fabric_id", "Fabric")


@app.get("/api/garments", response_model=list[GarmentOut])
def list_garments(): return list_records("garments", "garment_id", DESCENDING)

@app.post("/api/garments", response_model=GarmentOut, status_code=201)
def create_garment(payload: GarmentCreate): return create_record("garments", payload, "garment_id")

@app.put("/api/garments/{garment_id}", response_model=GarmentOut)
def put_garment(garment_id: int, payload: GarmentCreate): return update_record("garments", garment_id, payload, "garment_id", "Garment")

@app.delete("/api/garments/{garment_id}")
def remove_garment(garment_id: int): return delete_record("garments", garment_id, "garment_id", "Garment")


@app.get("/api/production")
def production():
    rows = []
    for garment in coll("garments").find({}, {"_id": 0}).sort("garment_id", DESCENDING):
        order = coll("orders").find_one({"order_id": garment["order_id"]}, {"_id": 0}) or {}
        customer = coll("customers").find_one({"customer_id": order.get("customer_id")}, {"_id": 0}) or {}
        design = coll("designs").find_one({"design_id": order.get("design_id")}, {"_id": 0}) or {}
        tailor = coll("tailors").find_one({"tailor_id": garment.get("tailor_id")}, {"_id": 0}) or {}
        rows.append({
            "garment_id": garment["garment_id"], "order_id": garment["order_id"],
            "customer": customer.get("name", "Unknown customer"), "tailor": tailor.get("name", "Unassigned"),
            "status": garment.get("stitching_status", "Pending"), "start": garment.get("stitching_start"),
            "end": garment.get("stitching_end"), "style": design.get("style_name", "Custom piece"),
        })
    return rows


@app.get("/api/garment-fabrics", response_model=list[GarmentFabricOut])
def list_garment_fabrics(): return list_records("garment_fabrics", "garment_id", ASCENDING)

@app.post("/api/garment-fabrics", response_model=GarmentFabricOut, status_code=201)
def create_garment_fabric(payload: GarmentFabricCreate):
    values = payload.model_dump(mode="json")
    validate_references("garment_fabrics", values)
    if coll("garment_fabrics").find_one({"garment_id": payload.garment_id, "fabric_id": payload.fabric_id}):
        raise HTTPException(status_code=409, detail="This fabric is already linked to this garment")
    try:
        coll("garment_fabrics").insert_one(values)
    except DuplicateKeyError as exc:
        raise HTTPException(status_code=409, detail="This fabric is already linked to this garment") from exc
    return values

@app.put("/api/garment-fabrics/{garment_id}/{fabric_id}", response_model=GarmentFabricOut)
def put_garment_fabric(garment_id: int, fabric_id: int, payload: GarmentFabricCreate):
    if payload.garment_id != garment_id or payload.fabric_id != fabric_id:
        raise HTTPException(status_code=400, detail="Composite key fields cannot be changed; delete and add a new link")
    query = {"garment_id": garment_id, "fabric_id": fabric_id}
    if not coll("garment_fabrics").find_one(query): raise HTTPException(status_code=404, detail="Garment–fabric link not found")
    values = payload.model_dump(mode="json")
    coll("garment_fabrics").update_one(query, {"$set": values})
    return values

@app.delete("/api/garment-fabrics/{garment_id}/{fabric_id}")
def remove_garment_fabric(garment_id: int, fabric_id: int):
    result = coll("garment_fabrics").delete_one({"garment_id": garment_id, "fabric_id": fabric_id})
    if result.deleted_count == 0: raise HTTPException(status_code=404, detail="Garment–fabric link not found")
    return {"deleted": True, "garment_id": garment_id, "fabric_id": fabric_id}


@app.get("/api/trials", response_model=list[TrialOut])
def list_trials(): return list_records("trial_sessions", "scheduled_date", ASCENDING)

@app.post("/api/trials", response_model=TrialOut, status_code=201)
def create_trial(payload: TrialCreate): return create_record("trial_sessions", payload, "trial_id")

@app.put("/api/trials/{trial_id}", response_model=TrialOut)
def put_trial(trial_id: int, payload: TrialCreate): return update_record("trial_sessions", trial_id, payload, "trial_id", "Trial session")

@app.delete("/api/trials/{trial_id}")
def remove_trial(trial_id: int): return delete_record("trial_sessions", trial_id, "trial_id", "Trial session")


@app.get("/api/deliveries", response_model=list[DeliveryOut])
def list_deliveries(): return list_records("deliveries", "delivery_date", ASCENDING)

@app.post("/api/deliveries", response_model=DeliveryOut, status_code=201)
def create_delivery(payload: DeliveryCreate): return create_record("deliveries", payload, "delivery_id")

@app.put("/api/deliveries/{delivery_id}", response_model=DeliveryOut)
def put_delivery(delivery_id: int, payload: DeliveryCreate): return update_record("deliveries", delivery_id, payload, "delivery_id", "Delivery")

@app.delete("/api/deliveries/{delivery_id}")
def remove_delivery(delivery_id: int): return delete_record("deliveries", delivery_id, "delivery_id", "Delivery")


@app.get("/api/database-summary")
def database_summary():
    try:
        client.admin.command("ping")
    except PyMongoError as exc:
        raise HTTPException(status_code=503, detail="MongoDB is unavailable") from exc
    return {
        "database": "MongoDB", "database_name": MONGODB_DB, "collection_count": len(COLLECTIONS),
        "table_count": len(COLLECTIONS),
        "connection_hint": f"mongodb://localhost:{MONGO_HOST_PORT}",
        "tables": [
            {"table": COLLECTIONS[name]["table"], "collection": name, "label": COLLECTIONS[name]["label"],
             "endpoint": COLLECTIONS[name]["endpoint"], "records": count(name)}
            for name in COLLECTIONS
        ],
    }


@app.get("/api/database/collections/{collection_name}")
def read_collection(collection_name: str, limit: int = Query(default=50, ge=1, le=200), skip: int = Query(default=0, ge=0)):
    if collection_name not in COLLECTIONS:
        raise HTTPException(status_code=404, detail="Unknown ERD collection")
    docs = list(coll(collection_name).find({}, {"_id": 0}).skip(skip).limit(limit))
    return {"collection": collection_name, "database": MONGODB_DB, "total": count(collection_name), "limit": limit, "skip": skip, "documents": docs}


@app.post("/api/seed")
def reseed():
    created = seed_demo()
    return {"seeded": created, "message": "Demo data created." if created else "Database already contains data; nothing was changed."}
